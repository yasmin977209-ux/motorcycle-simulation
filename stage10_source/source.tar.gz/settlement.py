"""Chapter 7 — isolated post-maturity settlement functions."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from typing import Optional

from constants import SETTLEMENT_DAILY_RENT, SETTLEMENT_PERIOD_DAYS
from dateutils import is_business_day
from entities import Bike, Contract, ReceivableEntry
from rng import derive_seed, rng_draw


@dataclass(frozen=True)
class SettlementRentResult:
    applied: bool
    due: int
    collected: int
    cash_delta: int
    accounts_receivable_delta: int
    partner1_memo_delta: int
    partner2_memo_delta: int


@dataclass(frozen=True)
class LegacyDebtCollectionResult:
    success: bool
    payment: int
    remaining_debt: int
    cash_delta: int
    accounts_receivable_delta: int
    partner1_memo_delta: int
    partner2_memo_delta: int


@dataclass(frozen=True)
class SettlementStatusResult:
    eligible_for_failure_check: bool
    elapsed_business_days: int
    should_fail: bool


def first_settlement_business_day_after(maturity_date: date) -> date:
    """The first business day strictly after the maturity day."""
    cursor = maturity_date + timedelta(days=1)
    while not is_business_day(cursor):
        cursor += timedelta(days=1)
    return cursor


def initialize_settlement_on_first_workday(
    bike: Bike,
    contract: Contract,
    current_date: date,
) -> None:
    """Set frozen legacy debt/start date on the first actual settlement day."""
    if bike.settlement_start_date is not None:
        return
    if contract.maturity_date is None:
        raise ValueError("settlement requires a maturity_date")
    first_day = first_settlement_business_day_after(contract.maturity_date)
    if current_date != first_day:
        raise ValueError("settlement_start_date can only be initialized on the first settlement workday")
    legacy = contract.total_due - contract.total_paid
    if legacy <= 0:
        raise ValueError("settlement requires positive legacy debt")
    bike.settlement_start_date = current_date
    bike.settlement_legacy_debt_original = legacy
    bike.settlement_legacy_debt_remaining = legacy
    bike.settlement_business_days_elapsed = 0


def apply_settlement_rent(
    *,
    is_settlement_state: bool,
    current_date: date,
) -> SettlementRentResult:
    """Deterministic 1,500 settlement rent on settlement workdays only."""
    if not is_settlement_state or not is_business_day(current_date):
        return SettlementRentResult(False, 0, 0, 0, 0, 0, 0)
    return SettlementRentResult(
        applied=True,
        due=SETTLEMENT_DAILY_RENT,
        collected=SETTLEMENT_DAILY_RENT,
        cash_delta=SETTLEMENT_DAILY_RENT,
        accounts_receivable_delta=0,
        partner1_memo_delta=(SETTLEMENT_DAILY_RENT * 70) // 100,
        partner2_memo_delta=(SETTLEMENT_DAILY_RENT * 30) // 100,
    )


def apply_legacy_debt_collection(
    bike: Bike,
    receivable: ReceivableEntry,
    *,
    probability: float,
    master_seed: int,
    scenario_id: str,
    trial_id: int,
    bike_id: str,
    current_date: date,
) -> LegacyDebtCollectionResult:
    """One independent legacy-debt RNG draw, capped at 1,500."""
    if not is_business_day(current_date):
        return LegacyDebtCollectionResult(False, 0, bike.settlement_legacy_debt_remaining or 0, 0, 0, 0, 0)
    remaining = bike.settlement_legacy_debt_remaining or 0
    if remaining <= 0:
        return LegacyDebtCollectionResult(False, 0, 0, 0, 0, 0, 0)

    if not 0.0 <= probability <= 1.0:
        raise ValueError("collection probability must be in [0, 1]")
    if probability == 1.0:
        success = True
    elif probability == 0.0:
        success = False
    else:
        seed = derive_seed(
            master_seed,
            scenario_id,
            trial_id,
            bike_id,
            current_date,
            "LEGACY_DEBT_COLLECTION",
        )
        success = rng_draw(seed) < probability

    if not success:
        return LegacyDebtCollectionResult(False, 0, remaining, 0, 0, 0, 0)

    payment = min(SETTLEMENT_DAILY_RENT, remaining)
    new_remaining = remaining - payment
    bike.settlement_legacy_debt_remaining = new_remaining
    receivable.collected_amount += payment
    receivable.remaining_amount = new_remaining
    receivable.status = "SETTLED" if new_remaining == 0 else "OUTSTANDING"
    if new_remaining == 0:
        receivable.settlement_date = current_date

    return LegacyDebtCollectionResult(
        success=True,
        payment=payment,
        remaining_debt=new_remaining,
        cash_delta=payment,
        accounts_receivable_delta=-payment,
        partner1_memo_delta=(payment * 70) // 100,
        partner2_memo_delta=(payment * 30) // 100,
    )


def settlement_status(
    settlement_start_date: Optional[date],
    current_date: date,
    legacy_debt_remaining: int,
) -> SettlementStatusResult:
    """M13 boundary: day 30 can remain in settlement; failure begins after day 30."""
    if settlement_start_date is None:
        return SettlementStatusResult(False, 0, False)
    if current_date < settlement_start_date:
        return SettlementStatusResult(False, 0, False)
    elapsed = 0
    cursor = settlement_start_date
    while cursor <= current_date:
        if is_business_day(cursor):
            elapsed += 1
        cursor += timedelta(days=1)
    should_fail = elapsed > SETTLEMENT_PERIOD_DAYS and legacy_debt_remaining > 0
    return SettlementStatusResult(True, elapsed, should_fail)
