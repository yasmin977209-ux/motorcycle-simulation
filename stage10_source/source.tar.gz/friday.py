"""Chapter 5 — isolated Friday fee and oil-service functions.

No daily simulation loop is defined here. The caller supplies the possession
snapshot; these functions only apply the Chapter 5 business rules.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta

from constants import FRIDAY_FEE, OIL_SERVICE_COST
from entities import Contract


@dataclass(frozen=True)
class FridayChargeResult:
    eligible: bool
    friday_number: int
    friday_fee: int
    oil_service_expense: int
    net_cash_delta: int
    partner1_memo_delta: int
    partner2_memo_delta: int


def _next_friday_after(day: date) -> date:
    """Return the first Friday strictly after ``day``."""
    days_ahead = (4 - day.weekday()) % 7
    if days_ahead == 0:
        days_ahead = 7
    return day + timedelta(days=days_ahead)


def eligible_friday_number(contract_start_or_delivery: date, current_date: date) -> int:
    """Chapter 5.2–5.3: determine the eligible Friday sequence number.

    Saturday/Sunday/Monday deliveries count the next Friday as #1.
    Tuesday/Wednesday/Thursday deliveries exempt the next Friday; the following
    Friday is #1. Contract starts are workdays under the reference, so Friday
    start dates are not valid inputs for this rule.
    """
    if current_date <= contract_start_or_delivery or current_date.weekday() != 4:
        return 0

    first_friday = _next_friday_after(contract_start_or_delivery)
    weekday = contract_start_or_delivery.weekday()

    if weekday in (5, 6, 0):
        eligible_first = first_friday
    elif weekday in (1, 2, 3):
        eligible_first = first_friday + timedelta(days=7)
    else:
        raise ValueError("Contract start/delivery cannot be Friday")

    if current_date < eligible_first:
        return 0
    delta_days = (current_date - eligible_first).days
    if delta_days % 7 != 0:
        return 0
    return delta_days // 7 + 1


def is_eligible_friday(contract_start_or_delivery: date, current_date: date) -> bool:
    """Boolean Chapter 5 eligibility test."""
    return eligible_friday_number(contract_start_or_delivery, current_date) > 0


def apply_friday_fee_and_oil(
    contract: Contract,
    contract_start_or_delivery: date,
    current_date: date,
    *,
    was_in_possession: bool,
) -> FridayChargeResult:
    """Apply one eligible Friday event to one contract.

    The possession snapshot is supplied by the caller exactly as required by
    M4. No rent is accrued here; Friday fee and oil are the only operations.
    """
    if not was_in_possession or not is_eligible_friday(contract_start_or_delivery, current_date):
        return FridayChargeResult(False, 0, 0, 0, 0, 0, 0)

    number = contract.friday_counter + 1
    oil = OIL_SERVICE_COST if number % 2 == 0 else 0
    fee = FRIDAY_FEE
    contract.friday_counter = number
    return FridayChargeResult(
        eligible=True,
        friday_number=number,
        friday_fee=fee,
        oil_service_expense=oil,
        net_cash_delta=fee - oil,
        partner1_memo_delta=(fee * 70) // 100,
        partner2_memo_delta=(fee * 30) // 100,
    )
