"""Chapter 9 — isolated guarantee-claim functions."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from constants import (
    ADMINISTRATIVE_CLOSURE_WAIT_DAYS,
    FINAL_CLOSURE_WAIT_DAYS,
    GUARANTEE_RECOVERY_RATES,
    POST_MATURITY_SETTLEMENT_FAILURE_WAIT_DAYS,
    PRIMARY_EARLY_TERMINATION_WAIT_DAYS,
    SECONDARY_EARLY_TERMINATION_WAIT_DAYS,
)
from dateutils import settlement_due_date
from entities import GuaranteeClaim


WAIT_BY_SOURCE = {
    "PRIMARY_EARLY_TERMINATION": PRIMARY_EARLY_TERMINATION_WAIT_DAYS,
    "SECONDARY_EARLY_TERMINATION": SECONDARY_EARLY_TERMINATION_WAIT_DAYS,
    "POST_MATURITY_SETTLEMENT_FAILURE": POST_MATURITY_SETTLEMENT_FAILURE_WAIT_DAYS,
    "ADMINISTRATIVE_CLOSURE": ADMINISTRATIVE_CLOSURE_WAIT_DAYS,
    "FINAL_CLOSURE": FINAL_CLOSURE_WAIT_DAYS,
}


@dataclass(frozen=True)
class GuaranteeSettlementResult:
    recovered_amount: int
    bad_debt_amount: int
    guarantee_receivable_delta: int
    cash_delta: int


def waiting_days_for_source(claim_source: str) -> int:
    try:
        return WAIT_BY_SOURCE[claim_source]
    except KeyError as exc:
        raise ValueError(f"Unsupported claim source: {claim_source}") from exc


def create_guarantee_claim(
    *,
    claim_id: str,
    bike_id: str,
    contract_id: str,
    tenant_id: str,
    guarantor_id: str,
    claim_source: str,
    claim_amount: int,
    created_date: date,
    recovery_rate_pct: int,
) -> GuaranteeClaim:
    """Create one claim and freeze its settlement_due_date immediately."""
    if claim_amount < 0:
        raise ValueError("claim_amount cannot be negative")
    if recovery_rate_pct not in GUARANTEE_RECOVERY_RATES:
        raise ValueError("recovery_rate_pct must be one of the reference rates")
    waiting = waiting_days_for_source(claim_source)
    return GuaranteeClaim(
        claim_id=claim_id,
        bike_id=bike_id,
        contract_id=contract_id,
        tenant_id=tenant_id,
        guarantor_id=guarantor_id,
        claim_source=claim_source,
        claim_amount=claim_amount,
        created_date=created_date,
        waiting_period_days=waiting,
        settlement_due_date=settlement_due_date(created_date, waiting),
        recovery_rate_pct=recovery_rate_pct,
    )


def can_settle_claim(claim: GuaranteeClaim, current_date: date) -> bool:
    """Only the stored due date controls natural settlement eligibility."""
    return claim.status == "PENDING" and current_date >= claim.settlement_due_date


def settle_guarantee_claim(
    claim: GuaranteeClaim,
    *,
    settlement_date: date,
) -> GuaranteeSettlementResult:
    """Apply deterministic percentage recovery; never calls RNG."""
    if claim.status != "PENDING":
        raise ValueError("claim must be PENDING before settlement")
    claim.settle_deterministically(settlement_date)
    assert claim.recovered_amount is not None
    assert claim.bad_debt_amount is not None
    return GuaranteeSettlementResult(
        recovered_amount=claim.recovered_amount,
        bad_debt_amount=claim.bad_debt_amount,
        guarantee_receivable_delta=-claim.claim_amount,
        cash_delta=claim.recovered_amount,
    )
