"""Chapter 8 — isolated depreciation and ownership write-off functions."""
from __future__ import annotations

from dataclasses import dataclass

from constants import DEPRECIATION_RATE_PER_DAY, MAX_DEPRECIATION
from entities import Bike


@dataclass(frozen=True)
class DepreciationResult:
    applied: bool
    depreciation_amount: int
    expense: int
    usage_days_increment: int
    new_accumulated_depreciation: int
    new_net_book_value: int


@dataclass(frozen=True)
class OwnershipWriteoffResult:
    writeoff_expense: int
    gross_assets_delta: int
    accumulated_depreciation_project_delta: int
    remaining_net_book_value: int


def apply_daily_depreciation(bike: Bike, *, was_in_possession: bool) -> DepreciationResult:
    """Apply 50 YER for one day of actual tenant possession, capped at 360,000."""
    if not was_in_possession or bike.net_book_value <= 0:
        return DepreciationResult(False, 0, 0, 0, bike.accumulated_depreciation, bike.net_book_value)

    amount = min(DEPRECIATION_RATE_PER_DAY, bike.net_book_value, MAX_DEPRECIATION - bike.accumulated_depreciation)
    if amount <= 0:
        return DepreciationResult(False, 0, 0, 0, bike.accumulated_depreciation, bike.net_book_value)

    bike.accumulated_depreciation += amount
    bike.usage_days += 1
    return DepreciationResult(
        applied=True,
        depreciation_amount=amount,
        expense=amount,
        usage_days_increment=1,
        new_accumulated_depreciation=bike.accumulated_depreciation,
        new_net_book_value=bike.net_book_value,
    )


def apply_ownership_writeoff(bike: Bike) -> OwnershipWriteoffResult:
    """Chapter 8.4: remove gross asset and accumulated depreciation on transfer."""
    if bike.current_state != "OWNED_TRANSFERRED":
        raise ValueError("ownership write-off requires OWNED_TRANSFERRED state")

    old_accumulated = bike.accumulated_depreciation
    writeoff = bike.gross_cost - old_accumulated
    if writeoff < 0:
        raise ValueError("accumulated depreciation cannot exceed gross cost")

    bike.accumulated_depreciation = bike.gross_cost
    return OwnershipWriteoffResult(
        writeoff_expense=writeoff,
        gross_assets_delta=-bike.gross_cost,
        accumulated_depreciation_project_delta=-old_accumulated,
        remaining_net_book_value=0,
    )
