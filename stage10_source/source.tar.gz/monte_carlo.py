"""Chapter 14 — Monte Carlo orchestration, daily statistical path, representatives.

Stage 5 only.  The daily engine remains the sole source of trial state transitions.
All trial randomness is already derived deterministically by rng.py from
(master seed, scenario, trial, bike, date, event type).

This module adds orchestration only: independent trials, deterministic worker
execution, raw daily snapshots needed by DAILY_DISTRIBUTION, representative
selection, replay of representative trials, and reproducibility fingerprints.
"""
from __future__ import annotations

from concurrent.futures import ProcessPoolExecutor
from dataclasses import asdict, dataclass
from datetime import date, timedelta
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from typing import Any, Iterable, Sequence

import numpy as np

from constants import COLLECTION_PROBABILITIES, GUARANTEE_RECOVERY_RATES, MASTER_SEED, TOTAL_CAPITAL
from daily_engine import create_initial_project, run_day


ACTIVE_STATES = {
    "ACTIVE_PRIMARY",
    "WAITING_PRIMARY",
    "NOTICE_PRIMARY",
    "GRACE_PRIMARY",
    "POST_MATURITY_SETTLEMENT",
    "ACTIVE_SECONDARY",
    "NOTICE_SECONDARY",
}


class ParquetUnavailableError(RuntimeError):
    """Raised only when Parquet output is requested without an installed engine."""


@dataclass(frozen=True)
class DailyTrialSnapshot:
    """One trial's calendar-day contribution to DAILY_DISTRIBUTION."""

    date: str
    is_business_day: bool
    cash: int
    net_equity: int
    active_bike_count: int
    owned_bike_count: int
    pending_claim_count: int


@dataclass(frozen=True)
class TrialResult:
    """Compact trial result plus optional complete calendar-day snapshots."""

    scenario_id: str
    collection_probability: float
    recovery_rate_pct: int
    trial_id: int
    final_close_date: str
    final_net_project_equity: int
    final_cash: int
    cumulative_project_profit: int
    operating_net_profit: int
    termination_count: int
    secondary_cycle_count: int
    owned_bikes: int
    held_assets: int
    total_operating_revenue: int
    bad_debt: int
    guarantee_recovered: int
    daily_snapshots: tuple[DailyTrialSnapshot, ...] = ()
    event_log: tuple[dict[str, Any], ...] = ()
    contracts: tuple[dict[str, Any], ...] = ()
    guarantee_claims: tuple[dict[str, Any], ...] = ()
    assets: tuple[dict[str, Any], ...] = ()


@dataclass(frozen=True)
class RepresentativeSelection:
    p50_trial_id: int
    p10_trial_id: int
    p90_trial_id: int
    loss_case_trial_id: int


@dataclass(frozen=True)
class WorkerEquivalenceRow:
    trial_id: int
    worker_1_sha256: str
    worker_2_sha256: str
    worker_4_sha256: str
    exact_1_eq_2: bool
    exact_1_eq_4: bool


def scenario_id(collection_probability: float, recovery_rate_pct: int) -> str:
    """Canonical scenario code from the 5×5 Chapter 14 matrix."""
    return f"C{collection_probability * 100:03.0f}_G{recovery_rate_pct:03d}"


def _date_key(value: date | str) -> str:
    return value.isoformat() if isinstance(value, date) else value


def _public_dataclass_dict(obj: Any) -> dict[str, Any]:
    return asdict(obj)


def _trial_daily_snapshot(project, current_date: date) -> DailyTrialSnapshot:
    active_bikes = sum(b.current_state in ACTIVE_STATES for b in project.bikes)
    owned_bikes = sum(b.current_state == "OWNED_TRANSFERRED" for b in project.bikes)
    pending_claims = sum(c.status == "PENDING" for c in project.guarantee_claims)
    return DailyTrialSnapshot(
        date=current_date.isoformat(),
        is_business_day=current_date.weekday() != 4,
        cash=project.project_cash,
        net_equity=project.capital + project.retained_earnings,
        active_bike_count=active_bikes,
        owned_bike_count=owned_bikes,
        pending_claim_count=pending_claims,
    )


def _event_dict(event) -> dict[str, Any]:
    return {
        "event_id": event.event_id,
        "date": event.date.isoformat(),
        "bike_id": event.bike_id,
        "event_type": event.event_type,
        "previous_state": event.previous_state,
        "new_state": event.new_state,
        "contract_id": event.contract_id,
        "tenant_id": event.tenant_id,
        "guarantor_id": event.guarantor_id,
        "amount_if_applicable": event.amount_if_applicable,
        "balance_before": event.balance_before,
        "balance_after": event.balance_after,
        "trigger_reason": event.trigger_reason,
        "notes": event.notes,
    }


def _contract_dict(contract) -> dict[str, Any]:
    return {
        "contract_id": contract.contract_id,
        "bike_id": contract.bike_id,
        "tenant_id": contract.tenant_id,
        "guarantor_id": contract.guarantor_id,
        "contract_type": contract.contract_type,
        "daily_rate": contract.daily_rate,
        "start_date": contract.start_date.isoformat(),
        "maturity_date": None if contract.maturity_date is None else contract.maturity_date.isoformat(),
        "status": contract.status,
        "total_due": contract.total_due,
        "total_paid": contract.total_paid,
        "friday_counter": contract.friday_counter,
    }


def _claim_dict(claim) -> dict[str, Any]:
    return {
        "claim_id": claim.claim_id,
        "bike_id": claim.bike_id,
        "contract_id": claim.contract_id,
        "tenant_id": claim.tenant_id,
        "guarantor_id": claim.guarantor_id,
        "claim_source": claim.claim_source,
        "claim_amount": claim.claim_amount,
        "created_date": claim.created_date.isoformat(),
        "waiting_period_days": claim.waiting_period_days,
        "settlement_due_date": claim.settlement_due_date.isoformat(),
        "recovery_rate_pct": claim.recovery_rate_pct,
        "settlement_date": None if claim.settlement_date is None else claim.settlement_date.isoformat(),
        "recovered_amount": claim.recovered_amount,
        "bad_debt_amount": claim.bad_debt_amount,
        "status": claim.status,
    }


def _asset_dict(bike) -> dict[str, Any]:
    return {
        "bike_id": bike.bike_id,
        "source": bike.source,
        "purchase_date": bike.purchase_date.isoformat(),
        "scheduled_ready_date": bike.scheduled_ready_date.isoformat(),
        "funding_completion_date": None if bike.funding_completion_date is None else bike.funding_completion_date.isoformat(),
        "actual_ready_date": None if bike.actual_ready_date is None else bike.actual_ready_date.isoformat(),
        "delivery_date": None if bike.delivery_date is None else bike.delivery_date.isoformat(),
        "gross_cost": bike.gross_cost,
        "accumulated_depreciation": bike.accumulated_depreciation,
        "net_book_value": bike.net_book_value,
        "current_state": bike.current_state,
        "termination_count": bike.termination_count,
        "secondary_cycle_count": bike.secondary_cycle_count,
        "usage_days": bike.usage_days,
        "lifecycle_cycle_number": bike.lifecycle_cycle_number,
    }


def _make_trial_result(project, *, collection_probability: float, recovery_rate_pct: int,
                       trial_id: int, scenario: str,
                       daily_snapshots: Sequence[DailyTrialSnapshot],
                       include_raw_logs: bool) -> TrialResult:
    final_close_date = project.final_close_date
    if final_close_date is None:
        raise AssertionError("Trial ended without a dynamic final_close_date")
    if project.final_net_project_equity is None:
        raise AssertionError("Trial ended without final_net_project_equity")

    raw_events = tuple(_event_dict(e) for e in project.event_log) if include_raw_logs else ()
    raw_contracts = tuple(_contract_dict(c) for c in project.contracts) if include_raw_logs else ()
    raw_claims = tuple(_claim_dict(c) for c in project.guarantee_claims) if include_raw_logs else ()
    raw_assets = tuple(_asset_dict(b) for b in project.bikes) if include_raw_logs else ()

    return TrialResult(
        scenario_id=scenario,
        collection_probability=collection_probability,
        recovery_rate_pct=recovery_rate_pct,
        trial_id=trial_id,
        final_close_date=final_close_date.isoformat(),
        final_net_project_equity=project.final_net_project_equity,
        final_cash=project.project_cash,
        cumulative_project_profit=project.cumulative_project_profit,
        operating_net_profit=project.operating_net_profit,
        termination_count=sum(b.termination_count for b in project.bikes),
        secondary_cycle_count=sum(b.secondary_cycle_count for b in project.bikes),
        owned_bikes=sum(b.current_state == "OWNED_TRANSFERRED" for b in project.bikes),
        held_assets=sum(b.current_state == "HELD_AS_ASSET" for b in project.bikes),
        total_operating_revenue=project.operating_revenue,
        bad_debt=project.bad_debt_expense,
        guarantee_recovered=sum(
            c.recovered_amount or 0 for c in project.guarantee_claims
        ),
        daily_snapshots=tuple(daily_snapshots),
        event_log=raw_events,
        contracts=raw_contracts,
        guarantee_claims=raw_claims,
        assets=raw_assets,
    )


def _run_trial_worker(args: tuple[float, int, int, str, bool, bool]) -> TrialResult:
    return run_trial(*args[:-2], keep_daily=args[-2], include_raw_logs=args[-1])


def run_trial(collection_probability: float, recovery_rate_pct: int, trial_id: int,
              scenario: str | None = None, *, keep_daily: bool = True,
              include_raw_logs: bool = False) -> TrialResult:
    """Run one complete trial from scratch until dynamic closure, with no day cap."""
    if not (0.0 <= collection_probability <= 1.0):
        raise ValueError("collection_probability must be in [0, 1]")
    if recovery_rate_pct not in GUARANTEE_RECOVERY_RATES:
        raise ValueError("recovery_rate_pct must be one of 100/70/50/30/0")
    scenario = scenario or scenario_id(collection_probability, recovery_rate_pct)

    project = create_initial_project(recovery_rate_pct=recovery_rate_pct)
    current_date = date(2027, 1, 1)
    snapshots: list[DailyTrialSnapshot] = []
    while True:
        run_day(
            project,
            current_date,
            collection_probability=collection_probability,
            scenario_id=scenario,
            trial_id=trial_id,
        )
        if keep_daily:
            snapshots.append(_trial_daily_snapshot(project, current_date))
        if project.simulation_stopped:
            break
        current_date += timedelta(days=1)

    return _make_trial_result(
        project,
        collection_probability=collection_probability,
        recovery_rate_pct=recovery_rate_pct,
        trial_id=trial_id,
        scenario=scenario,
        daily_snapshots=snapshots,
        include_raw_logs=include_raw_logs,
    )


def run_trials(collection_probability: float, recovery_rate_pct: int,
               trial_ids: Iterable[int], *, workers: int = 1,
               keep_daily: bool = True, include_raw_logs: bool = False) -> list[TrialResult]:
    """Run specified logical trial IDs serially or independently in processes.

    Ordering is always normalized by trial_id after worker completion. Since each
    RNG draw is keyed by trial_id rather than call order, execution order cannot
    alter a trial's result.
    """
    if workers < 1:
        raise ValueError("workers must be >= 1")
    ids = sorted(int(x) for x in trial_ids)
    scenario = scenario_id(collection_probability, recovery_rate_pct)
    args = [
        (collection_probability, recovery_rate_pct, trial_id, scenario, keep_daily, include_raw_logs)
        for trial_id in ids
    ]
    if workers == 1:
        results = [run_trial(*a[:-2], keep_daily=a[-2], include_raw_logs=a[-1]) for a in args]
    else:
        with ProcessPoolExecutor(max_workers=workers) as executor:
            results = list(executor.map(_run_trial_worker, args))
    return sorted(results, key=lambda r: r.trial_id)


def select_representative_trials(trials: Sequence[TrialResult]) -> RepresentativeSelection:
    """Select P50/P10/P90/Loss Case exactly by final equity and trial-id ties."""
    if not trials:
        raise ValueError("trials must not be empty")
    ordered = sorted(trials, key=lambda t: t.trial_id)
    equities = np.asarray([t.final_net_project_equity for t in ordered], dtype=np.int64)

    def nearest_quantile(q: float) -> TrialResult:
        target = np.quantile(equities, q, method="linear")
        return min(ordered, key=lambda t: (abs(t.final_net_project_equity - target), t.trial_id))

    p50 = nearest_quantile(0.50)
    p10 = nearest_quantile(0.10)
    p90 = nearest_quantile(0.90)
    loss_case = min(ordered, key=lambda t: (t.final_net_project_equity, t.trial_id))
    return RepresentativeSelection(
        p50_trial_id=p50.trial_id,
        p10_trial_id=p10.trial_id,
        p90_trial_id=p90.trial_id,
        loss_case_trial_id=loss_case.trial_id,
    )


def rerun_representative_trial(selection: RepresentativeSelection, *, label: str,
                               collection_probability: float, recovery_rate_pct: int,
                               include_raw_logs: bool = True) -> TrialResult:
    """Re-run one representative using the exact same logical trial_id and seed derivation."""
    trial_id_map = {
        "P50": selection.p50_trial_id,
        "P10": selection.p10_trial_id,
        "P90": selection.p90_trial_id,
        "Loss Case": selection.loss_case_trial_id,
    }
    if label not in trial_id_map:
        raise ValueError("label must be one of P50/P10/P90/Loss Case")
    return run_trial(
        collection_probability,
        recovery_rate_pct,
        trial_id_map[label],
        scenario_id(collection_probability, recovery_rate_pct),
        keep_daily=True,
        include_raw_logs=include_raw_logs,
    )


def build_daily_distribution(trials: Sequence[TrialResult]) -> list[dict[str, Any]]:
    """Build 14.7 daily calendar distribution, including is_business_day.

    A trial contributes on a date when it has not closed before that date, i.e.
    final_close_date >= date. Dates are retained continuously from the common
    project start through the latest close date; days with no active trials are
    omitted after all trials have closed.
    """
    if not trials:
        return []
    per_trial = {t.trial_id: {s.date: s for s in t.daily_snapshots} for t in trials}
    final_dates = {t.trial_id: t.final_close_date for t in trials}
    start = min(date.fromisoformat(t.daily_snapshots[0].date) for t in trials if t.daily_snapshots)
    end = max(date.fromisoformat(t.final_close_date) for t in trials)
    rows: list[dict[str, Any]] = []

    current = start
    while current <= end:
        ds = current.isoformat()
        active_values = []
        for t in trials:
            if t.final_close_date < ds:
                continue
            snapshot = per_trial[t.trial_id].get(ds)
            if snapshot is not None:
                active_values.append(snapshot)
        if active_values:
            rows.append({
                "date": ds,
                "is_business_day": current.weekday() != 4,
                "active_trial_count": len(active_values),
                **_quantile_columns(active_values, "cash", "Cash"),
                **_quantile_columns(active_values, "net_equity", "Net_Equity"),
                **_quantile_columns(active_values, "active_bike_count", "Active_Bikes"),
                **_quantile_columns(active_values, "owned_bike_count", "Owned_Bikes"),
                **_quantile_columns(active_values, "pending_claim_count", "Pending_Claims"),
            })
        current += timedelta(days=1)
    return rows


def _quantile_columns(values: Sequence[DailyTrialSnapshot], attr: str, prefix: str) -> dict[str, Any]:
    arr = np.asarray([getattr(v, attr) for v in values], dtype=np.float64)
    return {
        f"P10_{prefix}": float(np.quantile(arr, 0.10, method="linear")),
        f"P25_{prefix}": float(np.quantile(arr, 0.25, method="linear")),
        f"P50_{prefix}": float(np.quantile(arr, 0.50, method="linear")),
        f"P75_{prefix}": float(np.quantile(arr, 0.75, method="linear")),
        f"P90_{prefix}": float(np.quantile(arr, 0.90, method="linear")),
    }


def canonical_trial_payload(trial: TrialResult) -> dict[str, Any]:
    """Canonical JSON-safe representation used for literal reproducibility checks."""
    return {
        "scenario_id": trial.scenario_id,
        "collection_probability": trial.collection_probability,
        "recovery_rate_pct": trial.recovery_rate_pct,
        "trial_id": trial.trial_id,
        "final_close_date": trial.final_close_date,
        "final_net_project_equity": trial.final_net_project_equity,
        "final_cash": trial.final_cash,
        "cumulative_project_profit": trial.cumulative_project_profit,
        "operating_net_profit": trial.operating_net_profit,
        "termination_count": trial.termination_count,
        "secondary_cycle_count": trial.secondary_cycle_count,
        "owned_bikes": trial.owned_bikes,
        "held_assets": trial.held_assets,
        "total_operating_revenue": trial.total_operating_revenue,
        "bad_debt": trial.bad_debt,
        "guarantee_recovered": trial.guarantee_recovered,
        "daily_snapshots": [_public_dataclass_dict(s) for s in trial.daily_snapshots],
        "event_log": list(trial.event_log),
        "contracts": list(trial.contracts),
        "guarantee_claims": list(trial.guarantee_claims),
        "assets": list(trial.assets),
    }


def trial_fingerprint(trial: TrialResult) -> str:
    """SHA-256 of the canonical complete trial payload."""
    blob = json.dumps(
        canonical_trial_payload(trial),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()


def _run_worker_group_in_fresh_process(collection_probability: float, recovery_rate_pct: int,
                                       trial_ids: Sequence[int], workers: int) -> dict[int, str]:
    """Run one worker-count group in a fresh Python process and return trial fingerprints.

    The production worker path remains ``run_trials``; this helper only isolates
    repeated process-pool measurements so they cannot inherit runtime state from
    a previous pool.
    """
    runner = Path(__file__).resolve().parent / "tests" / "run_worker_group.py"
    if tuple(trial_ids) != (1, 2, 3) or collection_probability != 1.0 or recovery_rate_pct != 100:
        raise ValueError("the built-in worker equivalence check is fixed to C100_G100 trials 1,2,3")
    completed = subprocess.run(
        [sys.executable, str(runner), str(workers)],
        cwd=str(Path(__file__).resolve().parent),
        env={**__import__('os').environ, "PYTHONPATH": str(Path(__file__).resolve().parent)},
        text=True,
        capture_output=True,
        check=True,
        timeout=300,
    )
    fingerprints: dict[int, str] = {}
    for line in completed.stdout.splitlines():
        parts = line.split()
        if len(parts) == 2:
            fingerprints[int(parts[0])] = parts[1]
    if set(fingerprints) != set(int(x) for x in trial_ids):
        raise AssertionError(f"worker group {workers} returned incomplete trial fingerprints: {completed.stdout!r}")
    return fingerprints


def compare_worker_counts(collection_probability: float = 1.0, recovery_rate_pct: int = 100,
                          trial_ids: Sequence[int] = (1, 2, 3)) -> list[WorkerEquivalenceRow]:
    """Run C100_G100 trial IDs 1–3 with 1, 2 and 4 workers and compare SHA-256 payloads."""
    ids = tuple(sorted(int(x) for x in trial_ids))
    if ids != (1, 2, 3):
        raise ValueError("worker equivalence proof requires trials (1, 2, 3)")
    by_workers = {
        workers: _run_worker_group_in_fresh_process(collection_probability, recovery_rate_pct, ids, workers)
        for workers in (1, 2, 4)
    }
    return [
        WorkerEquivalenceRow(
            trial_id=trial_id,
            worker_1_sha256=by_workers[1][trial_id],
            worker_2_sha256=by_workers[2][trial_id],
            worker_4_sha256=by_workers[4][trial_id],
            exact_1_eq_2=(by_workers[1][trial_id] == by_workers[2][trial_id]),
            exact_1_eq_4=(by_workers[1][trial_id] == by_workers[4][trial_id]),
        )
        for trial_id in ids
    ]


def save_trial_daily_json(trial: TrialResult, output_dir: str | Path) -> Path:
    """Persist raw calendar-day snapshots; JSON is used for this list-oriented state slice."""
    path = Path(output_dir)
    path.mkdir(parents=True, exist_ok=True)
    out = path / f"{trial.scenario_id}_trial_{trial.trial_id:06d}_daily.json"
    payload = [_public_dataclass_dict(s) for s in trial.daily_snapshots]
    out.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    return out


def save_daily_distribution_parquet(rows: Sequence[dict[str, Any]], output_path: str | Path) -> Path:
    """Write DAILY_DISTRIBUTION as Parquet when a supported engine is installed."""
    try:
        import pyarrow as pa
        import pyarrow.parquet as pq
    except ImportError as exc:
        raise ParquetUnavailableError(
            "Parquet output requested, but pyarrow is not installed in this execution environment."
        ) from exc
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    table = pa.Table.from_pylist(list(rows))
    pq.write_table(table, output)
    return output


__all__ = [
    "DailyTrialSnapshot",
    "ParquetUnavailableError",
    "TrialResult",
    "RepresentativeSelection",
    "WorkerEquivalenceRow",
    "build_daily_distribution",
    "canonical_trial_payload",
    "compare_worker_counts",
    "rerun_representative_trial",
    "run_trial",
    "run_trials",
    "save_daily_distribution_parquet",
    "save_trial_daily_json",
    "scenario_id",
    "select_representative_trials",
    "trial_fingerprint",
]
