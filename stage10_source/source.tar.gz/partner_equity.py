"""Chapter 11 — partner reinvestment memo balances."""
from __future__ import annotations
from constants import PARTNER1_FINAL_SHARE_PCT, PARTNER2_FINAL_SHARE_PCT, EXPANSION_PURCHASE_CASH_THRESHOLD
from entities import Project


def record_eligible_inflow(project: Project, amount: int) -> None:
    if amount < 0:
        raise ValueError("inflow cannot be negative")
    p1 = (amount * PARTNER1_FINAL_SHARE_PCT) // 100
    p2 = (amount * PARTNER2_FINAL_SHARE_PCT) // 100
    project.partner1_reinvestment_balance += p1
    project.partner2_reinvestment_balance += p2


def can_spend_expansion(project: Project, amount: int) -> bool:
    return (
        amount >= 0
        and project.project_cash >= amount
        and project.partner1_reinvestment_balance >= amount
    )


def spend_from_partner1_memo(project: Project, amount: int) -> None:
    if amount < 0:
        raise ValueError("memo spending cannot be negative")
    if not can_spend_expansion(project, amount):
        raise ValueError("insufficient cash or Partner1 memo balance")
    project.partner1_reinvestment_balance -= amount


def expansion_purchase_is_eligible(project: Project) -> bool:
    return can_spend_expansion(project, EXPANSION_PURCHASE_CASH_THRESHOLD)


def final_entitlements(project: Project, final_net_project_equity: int) -> tuple[int, int]:
    if final_net_project_equity < 0:
        raise ValueError("negative final equity is outside the final allocation rule")
    p1 = (final_net_project_equity * PARTNER1_FINAL_SHARE_PCT) // 100
    p2 = final_net_project_equity - p1
    return p1, p2
