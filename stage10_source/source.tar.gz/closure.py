"""Chapter 13 — dynamic closure and force-settlement procedures."""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date
from constants import EXPANSION_CUTOFF_DATE, PRIMARY_EARLY_TERMINATION_WAIT_DAYS
from accounting import transfer_ar_to_guarantee, settle_guarantee_accounting, balance_sheet_snapshot
from guarantee import create_guarantee_claim
from partner_equity import record_eligible_inflow, final_entitlements
from state_machine import apply_dynamic_closure


@dataclass(frozen=True)
class ClosureResult:
    closed: bool
    final_close_date: date | None
    final_net_project_equity: int | None
    partner1_entitlement: int | None
    partner2_entitlement: int | None


def closure_preconditions_met(project, current_date: date) -> bool:
    no_prep = not any(b.current_state == "PREP" for b in project.bikes)
    no_primary_active = not any(b.current_state in {
        "ACTIVE_PRIMARY", "WAITING_PRIMARY", "NOTICE_PRIMARY", "GRACE_PRIMARY"
    } for b in project.bikes)
    no_settlement_active = not any(b.current_state == "POST_MATURITY_SETTLEMENT" for b in project.bikes)
    expansion_window_closed = current_date > EXPANSION_CUTOFF_DATE
    return no_prep and no_primary_active and no_settlement_active and expansion_window_closed


def _next_id(prefix: str, collection) -> str:
    return f"{prefix}{len(collection) + 1:06d}"


def force_settle_pending_claim(project, claim, current_date: date) -> None:
    if claim.status != "PENDING":
        return
    recovered = (claim.claim_amount * claim.recovery_rate_pct) // 100
    bad_debt = claim.claim_amount - recovered
    settle_guarantee_accounting(project, claim.claim_amount, recovered, bad_debt)
    record_eligible_inflow(project, recovered)
    claim.recovered_amount = recovered
    claim.bad_debt_amount = bad_debt
    claim.status = "SETTLED"
    claim.settlement_date = current_date
    bike = next((b for b in project.bikes if b.bike_id == claim.bike_id), None)
    if bike is not None:
        project.event_log.append(project.make_event(
            event_id=_next_id("EV", project.event_log), event_date=current_date, bike=bike,
            event_type="GUARANTEE_RECOVERED" if recovered > 0 else "GUARANTEE_WRITTEN_OFF",
            contract_id=claim.contract_id, amount=claim.claim_amount, before=claim.claim_amount, after=0,
            reason=claim.claim_source,
        ))


def execute_dynamic_closure(project, current_date: date) -> ClosureResult:
    if not closure_preconditions_met(project, current_date):
        return ClosureResult(False, None, None, None, None)

    # 1) Administrative closure of surviving secondary contracts.
    for bike in list(project.bikes):
        if bike.current_state not in {"ACTIVE_SECONDARY", "NOTICE_SECONDARY"}:
            continue
        contract = next((c for c in project.contracts if c.contract_id == bike.current_contract_id), None)
        tenant = next((t for t in project.tenants if t.tenant_id == bike.current_tenant_id), None)
        outstanding = 0 if contract is None else contract.total_due - contract.total_paid
        if contract is not None and outstanding > 0:
            claim = create_guarantee_claim(
                claim_id=_next_id("CL", project.guarantee_claims),
                bike_id=bike.bike_id,
                contract_id=contract.contract_id,
                tenant_id=contract.tenant_id,
                guarantor_id=contract.guarantor_id,
                claim_source="ADMINISTRATIVE_CLOSURE",
                claim_amount=outstanding,
                created_date=current_date,
                recovery_rate_pct=project.recovery_rate_pct,
            )
            project.guarantee_claims.append(claim)
            transfer_ar_to_guarantee(project, outstanding)
        if contract is not None:
            contract.status = "TERMINATED"
        if tenant is not None:
            tenant.end_date = current_date
        bike.current_state = "HELD_AS_ASSET"
        bike.current_contract_id = None
        bike.current_tenant_id = None
        previous_state = "ACTIVE_SECONDARY" if contract is not None and contract.total_paid == contract.total_due else "NOTICE_SECONDARY"
        project.event_log.append(project.make_event(
            event_id=_next_id("EV", project.event_log),
            event_date=current_date,
            bike=bike,
            event_type="ADMINISTRATIVE_CLOSURE",
            previous_state=previous_state,
            new_state="HELD_AS_ASSET",
            contract_id=None if contract is None else contract.contract_id,
            amount=outstanding,
            reason="dynamic closure administrative termination",
        ))

    # 2) Force-settle every pending guarantee claim regardless of its natural due date.
    for claim in list(project.guarantee_claims):
        force_settle_pending_claim(project, claim, current_date)

    # 3) Safety-net all outstanding receivables.
    for receivable in list(project.receivables):
        if receivable.status != "OUTSTANDING" or receivable.remaining_amount <= 0:
            continue
        claim = create_guarantee_claim(
            claim_id=_next_id("CL", project.guarantee_claims),
            bike_id=receivable.bike_id,
            contract_id=receivable.contract_id,
            tenant_id=receivable.tenant_id,
            guarantor_id=next((c.guarantor_id for c in project.contracts if c.contract_id == receivable.contract_id), ""),
            claim_source="FINAL_CLOSURE",
            claim_amount=receivable.remaining_amount,
            created_date=current_date,
            recovery_rate_pct=project.recovery_rate_pct,
        )
        project.guarantee_claims.append(claim)
        transfer_ar_to_guarantee(project, receivable.remaining_amount)
        force_settle_pending_claim(project, claim, current_date)
        receivable.status = "SETTLED"
        receivable.settlement_date = current_date
        receivable.remaining_amount = 0

    # 4) Remaining bikes become held assets; owned are already out of project books.
    for bike in project.bikes:
        if bike.current_state not in {"OWNED_TRANSFERRED", "HELD_AS_ASSET"}:
            previous = bike.current_state
            bike.current_state = "HELD_AS_ASSET"
            project.event_log.append(project.make_event(
                event_id=_next_id("EV", project.event_log),
                event_date=current_date,
                bike=bike,
                event_type="FINAL_ASSET_HELD",
                previous_state=previous,
                new_state="HELD_AS_ASSET",
                reason="dynamic final closure",
            ))

    # 5) Final equity and allocations.
    held_net = sum(b.net_book_value for b in project.bikes if b.current_state == "HELD_AS_ASSET")
    final_net = project.project_cash + held_net
    p1, p2 = final_entitlements(project, final_net)
    project.final_close_date = current_date
    project.final_net_project_equity = final_net
    project.partner1_final_entitlement = p1
    project.partner2_final_entitlement = p2
    project.simulation_stopped = True

    # Guard final state consistency before M16/M17 continue.
    project.closure_balance_snapshot = balance_sheet_snapshot(project)
    return ClosureResult(True, current_date, final_net, p1, p2)
