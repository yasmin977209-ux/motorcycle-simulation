from datetime import date

from entities import Bike
from state_machine import (
    BikeState,
    TRANSITION_TABLE,
    apply_dynamic_closure,
    classify_daily_balance,
    derive_state_from_balance,
    resolve_primary_maturity,
    resolve_settlement,
    start_contract_from_prep,
    terminate_for_default,
    validate_transition_table,
)


def test_entities_have_reference_shape_and_forbidden_fields_absent():
    bike = Bike(
        bike_id="BK001",
        source="INITIAL",
        purchase_date=date(2026, 12, 26),
        scheduled_ready_date=date(2027, 1, 1),
        prep_paid=True,
        customs_paid=True,
        gross_cost=360_000,
    )
    assert bike.current_state == "PREP"
    assert bike.net_book_value == 360_000
    assert not hasattr(bike, "total_due")
    assert not hasattr(bike, "total_paid")
    assert not hasattr(bike, "friday_counter")
    assert not hasattr(bike, "notice_start_date")
    assert not hasattr(bike, "grace_start_date")
    assert not hasattr(bike, "legacy_debt_amount")


def test_exact_11_states_and_transition_table():
    validate_transition_table()
    assert len(BikeState) == 11
    assert len(TRANSITION_TABLE) == 18


def test_reference_balance_derivation_boundaries():
    assert derive_state_from_balance(0, 1_500, "PRIMARY") == "ACTIVE_PRIMARY"
    assert derive_state_from_balance(31_499, 1_500, "PRIMARY") == "WAITING_PRIMARY"
    assert derive_state_from_balance(31_500, 1_500, "PRIMARY") == "NOTICE_PRIMARY"
    assert derive_state_from_balance(42_000, 1_500, "PRIMARY") == "GRACE_PRIMARY"
    assert derive_state_from_balance(44_999, 1_500, "PRIMARY") == "GRACE_PRIMARY"
    assert derive_state_from_balance(45_000, 1_500, "PRIMARY") is None
    assert derive_state_from_balance(0, 1_000, "SECONDARY") == "ACTIVE_SECONDARY"
    assert derive_state_from_balance(9_999, 1_000, "SECONDARY") == "NOTICE_SECONDARY"
    assert derive_state_from_balance(10_000, 1_000, "SECONDARY") is None


def test_reference_path_1_natural():
    state = "PREP"
    state = start_contract_from_prep(
        state,
        prep_paid=True,
        customs_paid=True,
        actual_ready_date=date(2027, 1, 1),
        current_date=date(2027, 1, 2),
        contract_type="PRIMARY",
    )
    state = classify_daily_balance(state, 0, 1_500, "PRIMARY")
    state = resolve_primary_maturity(
        state,
        current_date=date(2029, 1, 2),
        maturity_date=date(2029, 1, 2),
        total_due=1_095_000,
        total_paid=1_095_000,
    )
    assert state == "OWNED_TRANSFERRED"


def test_reference_path_2_early_primary_delinquency():
    state = "PREP"
    state = start_contract_from_prep(
        state,
        prep_paid=True,
        customs_paid=True,
        actual_ready_date=date(2027, 1, 1),
        current_date=date(2027, 1, 2),
        contract_type="PRIMARY",
    )
    state = classify_daily_balance(state, 1_500, 1_500, "PRIMARY")
    assert state == "WAITING_PRIMARY"
    state = classify_daily_balance(state, 31_500, 1_500, "PRIMARY")
    assert state == "NOTICE_PRIMARY"
    state = classify_daily_balance(state, 42_000, 1_500, "PRIMARY")
    assert state == "GRACE_PRIMARY"
    state = terminate_for_default(state, 45_000, "PRIMARY")
    assert state == "AVAILABLE_FOR_SECONDARY"
    state = start_contract_from_prep(
        state,
        prep_paid=True,
        customs_paid=True,
        actual_ready_date=date(2027, 1, 3),
        current_date=date(2027, 1, 4),
        contract_type="SECONDARY",
    )
    assert state == "ACTIVE_SECONDARY"


def test_reference_path_3_maturity_debt_settlement_success():
    state = resolve_primary_maturity(
        "ACTIVE_PRIMARY",
        current_date=date(2029, 1, 2),
        maturity_date=date(2029, 1, 2),
        total_due=1_095_000,
        total_paid=1_093_500,
    )
    assert state == "POST_MATURITY_SETTLEMENT"
    state = resolve_settlement(
        state,
        legacy_debt_remaining=0,
        settlement_failed=False,
    )
    assert state == "OWNED_TRANSFERRED"


def test_reference_path_4_maturity_debt_settlement_failure():
    state = resolve_primary_maturity(
        "ACTIVE_PRIMARY",
        current_date=date(2029, 1, 2),
        maturity_date=date(2029, 1, 2),
        total_due=1_095_000,
        total_paid=1_000_000,
    )
    assert state == "POST_MATURITY_SETTLEMENT"
    state = resolve_settlement(
        state,
        legacy_debt_remaining=95_000,
        settlement_failed=True,
    )
    assert state == "AVAILABLE_FOR_SECONDARY"


def test_reference_path_5_repeated_secondary():
    state = "ACTIVE_SECONDARY"
    state = classify_daily_balance(state, 1_000, 1_000, "SECONDARY")
    assert state == "NOTICE_SECONDARY"
    state = terminate_for_default(state, 10_000, "SECONDARY")
    assert state == "AVAILABLE_FOR_SECONDARY"
    state = start_contract_from_prep(
        state,
        prep_paid=True,
        customs_paid=True,
        actual_ready_date=date(2027, 1, 4),
        current_date=date(2027, 1, 4),
        contract_type="SECONDARY",
    )
    assert state == "ACTIVE_SECONDARY"


def test_reference_path_6_dynamic_closure():
    active_states = [
        "ACTIVE_PRIMARY",
        "WAITING_PRIMARY",
        "NOTICE_PRIMARY",
        "GRACE_PRIMARY",
        "POST_MATURITY_SETTLEMENT",
        "ACTIVE_SECONDARY",
        "NOTICE_SECONDARY",
    ]
    for state in active_states:
        assert apply_dynamic_closure(state, closure_conditions_met=True) == "HELD_AS_ASSET"
    assert apply_dynamic_closure("OWNED_TRANSFERRED", closure_conditions_met=True) == "OWNED_TRANSFERRED"


def test_memoryless_derivation_does_not_depend_on_current_state():
    assert derive_state_from_balance(31_500, 1_500, "PRIMARY") == "NOTICE_PRIMARY"
    assert derive_state_from_balance(31_500, 1_500, "PRIMARY") == "NOTICE_PRIMARY"
