from datetime import date
import subprocess, sys

import constants
from dateutils import (
    count_business_days,
    delivery_date,
    eligible_friday,
    friday_counter_for_date,
    primary_maturity_date,
    scheduled_ready_date,
    settlement_due_date,
)
from rng import derive_seed, rng_draw, scenario_id


def test_opening_constants():
    assert constants.PROJECT_START_DATE == date(2027, 1, 1)
    assert constants.INITIAL_FLEET_PURCHASE_DATE == date(2026, 12, 26)
    assert constants.INITIAL_FLEET_READY_DATE == date(2027, 1, 1)
    assert constants.INITIAL_FLEET_DELIVERY_DATE == date(2027, 1, 2)
    assert constants.TOTAL_CAPITAL == 3_700_000
    assert constants.OPENING_BIKE_ASSETS == 3_600_000
    assert constants.OPENING_RETAINED_LOSS == -100_000
    assert constants.PRIMARY_CONTRACT_MONTHS == 24


def test_reference_initial_prep_and_delivery():
    assert scheduled_ready_date(date(2026, 12, 26)) == date(2027, 1, 1)
    assert delivery_date(date(2027, 1, 1)) == date(2027, 1, 2)


def test_reference_primary_maturity_uses_calendar_months():
    assert primary_maturity_date(date(2027, 1, 2)) == date(2029, 1, 2)
    assert primary_maturity_date(date(2028, 2, 29)) == date(2030, 2, 28)


def test_reference_claim_due_date():
    assert settlement_due_date(date(2027, 1, 15), 20) == date(2027, 2, 5)
    assert settlement_due_date(date(2027, 1, 15), 0) == date(2027, 1, 15)


def test_reference_friday_eligibility():
    # السبت 2027-01-02 -> الجمعة 2027-01-09 مؤهلة #1
    assert eligible_friday(date(2027, 1, 2), date(2027, 1, 8))
    assert friday_counter_for_date(date(2027, 1, 2), date(2027, 1, 8)) == 1
    assert friday_counter_for_date(date(2027, 1, 2), date(2027, 1, 15)) == 2

    # الأحد 2027-01-03 -> 2027-01-09 #1
    assert eligible_friday(date(2027, 1, 3), date(2027, 1, 8))
    # الاثنين 2027-01-04 -> 2027-01-09 #1
    assert eligible_friday(date(2027, 1, 4), date(2027, 1, 8))
    # الثلاثاء/الأربعاء/الخميس: الجمعة التالية معفاة
    assert not eligible_friday(date(2027, 1, 5), date(2027, 1, 8))
    assert eligible_friday(date(2027, 1, 5), date(2027, 1, 15))
    assert not eligible_friday(date(2027, 1, 6), date(2027, 1, 8))
    assert eligible_friday(date(2027, 1, 6), date(2027, 1, 15))
    assert not eligible_friday(date(2027, 1, 7), date(2027, 1, 8))
    assert eligible_friday(date(2027, 1, 7), date(2027, 1, 15))


def test_fridays_are_non_business_days_and_count_business_days():
    assert not (date(2027, 1, 1).weekday() != 4)
    assert count_business_days(date(2027, 1, 1), date(2027, 1, 4)) == 3


def test_rng_reference_algorithm():
    seed = derive_seed(20270101, "C085_G070", 1, "BK001", date(2027, 1, 8), "PRIMARY_COLLECTION")
    assert len(seed) == 32
    expected = int.from_bytes(seed[:8], "big") / 2**64
    assert rng_draw(seed) == expected
    assert 0.0 <= rng_draw(seed) < 1.0


def test_rng_reproducibility_and_independence():
    args = (constants.MASTER_SEED, "C085_G070", 17, "BK001", date(2028, 3, 10), "PRIMARY_COLLECTION")
    assert derive_seed(*args) == derive_seed(*args)
    assert derive_seed(*args) != derive_seed(constants.MASTER_SEED, "C070_G070", 17, "BK001", date(2028, 3, 10), "PRIMARY_COLLECTION")
    assert derive_seed(*args) != derive_seed(constants.MASTER_SEED, "C085_G070", 18, "BK001", date(2028, 3, 10), "PRIMARY_COLLECTION")
    assert derive_seed(*args) != derive_seed(constants.MASTER_SEED, "C085_G070", 17, "BK002", date(2028, 3, 10), "PRIMARY_COLLECTION")
    assert derive_seed(*args) != derive_seed(constants.MASTER_SEED, "C085_G070", 17, "BK001", date(2028, 3, 11), "PRIMARY_COLLECTION")
    assert derive_seed(*args) != derive_seed(constants.MASTER_SEED, "C085_G070", 17, "BK001", date(2028, 3, 10), "SECONDARY_COLLECTION")


def test_scenario_naming():
    assert scenario_id(0.85, 70) == "C085_G070"
    assert scenario_id(1.0, 100) == "C100_G100"


def test_no_builtin_hash_used_in_rng():
    src = open("rng.py", encoding="utf-8").read()
    assert "hash(" not in src
