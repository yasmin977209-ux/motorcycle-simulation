from datetime import date
from pathlib import Path
import json

from monte_carlo import TrialResult
from run_batch import (
    atomic_write_json,
    checkpoint_metrics,
    final_entitlements,
    load_or_create_state,
    next_checkpoint_size,
    project_ci_gate,
    reference_is_stable,
    reference_start_repetitions,
    save_manifest,
    verify_manifest,
)


def trial(equity: int, trial_id: int = 1) -> TrialResult:
    return TrialResult(
        scenario_id="C100_G100", collection_probability=1.0, recovery_rate_pct=100,
        trial_id=trial_id, final_close_date="2033-01-06", final_net_project_equity=equity,
        final_cash=equity, cumulative_project_profit=equity - 3_700_100,
        operating_net_profit=equity - 3_600_000, termination_count=0,
        secondary_cycle_count=0, owned_bikes=10, held_assets=0,
        total_operating_revenue=0, bad_debt=0, guarantee_recovered=0,
    )


def test_reference_starts_and_escalation():
    assert reference_start_repetitions(1.0) == 200
    assert reference_start_repetitions(0.85) == 5_000
    assert reference_start_repetitions(0.70) == 8_000
    assert reference_start_repetitions(0.50) == 15_000
    assert reference_start_repetitions(0.30) == 20_000
    assert next_checkpoint_size(20_000, 0.30) == 40_000
    assert next_checkpoint_size(80_000, 0.30) == 100_000
    assert next_checkpoint_size(100_000, 0.30) == 200_000


def test_atomic_state_and_manifest(tmp_path: Path):
    state = load_or_create_state(tmp_path, ["C100_G100"])
    assert state["stage"] == 8
    payload = {"ok": True, "when": "test"}
    atomic_write_json(tmp_path / "state_probe.json", payload)
    assert json.loads((tmp_path / "state_probe.json").read_text()) == payload
    manifest = {"stage": 8, "format": "test", "trial_count": 0, "trials": []}
    save_manifest(tmp_path, manifest)
    verify_manifest(tmp_path, json.loads((tmp_path / "manifest.json").read_text()))
    assert (tmp_path / "manifest.sha256.json").exists()


def test_reference_stability_math():
    assert reference_is_stable(1000, 1009) is True
    assert reference_is_stable(1000, 1010) is False
    assert reference_is_stable(0.0, 0.5) is True
    assert reference_is_stable(0.0, 1.0) is False


def test_project_ci_gate_has_300_minimum():
    small = [trial(100, i) for i in range(1, 300)]
    assert project_ci_gate(small)["eligible"] is False
    full = [trial(100, i) for i in range(1, 301)]
    gate = project_ci_gate(full)
    assert gate["eligible"] is True
    assert gate["pass"] is True
    assert final_entitlements(101) == (70, 31)
