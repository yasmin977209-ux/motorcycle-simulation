from datetime import date, timedelta

import pytest

from collection import apply_ordinary_collection
from constants import (
    BIKE_GROSS_ASSET_COST,
    FRIDAY_FEE,
    MASTER_SEED,
    OIL_SERVICE_COST,
    PRIMARY_DAILY_RENT,
    SECONDARY_DAILY_RENT,
    SETTLEMENT_PERIOD_DAYS,
)
from depreciation import apply_daily_depreciation, apply_ownership_writeoff
from entities import Bike, Contract, GuaranteeClaim, ReceivableEntry
from friday import apply_friday_fee_and_oil, eligible_friday_number
from guarantee import can_settle_claim, create_guarantee_claim, settle_guarantee_claim
from settlement import (
    apply_legacy_debt_collection,
    apply_settlement_rent,
    first_settlement_business_day_after,
    initialize_settlement_on_first_workday,
    settlement_status,
)
from state_machine import BikeState, derive_state_from_balance, resolve_primary_maturity, terminate_for_default


def primary_contract(**kwargs):
    base = dict(
        contract_id="CT1", bike_id="BK1", tenant_id="TN1", guarantor_id="GR1",
        contract_type="PRIMARY", daily_rate=PRIMARY_DAILY_RENT,
        start_date=date(2027, 1, 2), maturity_date=date(2029, 1, 2),
    )
    base.update(kwargs)
    return Contract(**base)


def secondary_contract(**kwargs):
    base = dict(
        contract_id="CT2", bike_id="BK1", tenant_id="TN2", guarantor_id="GR2",
        contract_type="SECONDARY", daily_rate=SECONDARY_DAILY_RENT,
        start_date=date(2027, 2, 5),
    )
    base.update(kwargs)
    return Contract(**base)


def bike(**kwargs):
    base = dict(
        bike_id="BK1", source="INITIAL", purchase_date=date(2026, 12, 26),
        scheduled_ready_date=date(2027, 1, 1), actual_ready_date=date(2027, 1, 1),
        prep_paid=True, customs_paid=True, gross_cost=BIKE_GROSS_ASSET_COST,
    )
    base.update(kwargs)
    return Bike(**base)


# باب 5 — الجمعة والزيت

def test_friday_rule_real_calendar_for_saturday_delivery():
    assert eligible_friday_number(date(2027, 1, 2), date(2027, 1, 8)) == 1
    assert eligible_friday_number(date(2027, 1, 2), date(2027, 1, 15)) == 2


def test_friday_rule_exempts_next_friday_for_tuesday_delivery():
    assert eligible_friday_number(date(2027, 1, 5), date(2027, 1, 8)) == 0
    assert eligible_friday_number(date(2027, 1, 5), date(2027, 1, 15)) == 1


def test_friday_fee_first_and_second_number():
    contract = primary_contract()
    first = apply_friday_fee_and_oil(contract, date(2027, 1, 2), date(2027, 1, 8), was_in_possession=True)
    second = apply_friday_fee_and_oil(contract, date(2027, 1, 2), date(2027, 1, 15), was_in_possession=True)
    assert first.friday_number == 1
    assert first.friday_fee == FRIDAY_FEE
    assert first.oil_service_expense == 0
    assert second.friday_number == 2
    assert second.oil_service_expense == OIL_SERVICE_COST
    assert second.net_cash_delta == FRIDAY_FEE - OIL_SERVICE_COST


def test_friday_requires_possession_snapshot():
    contract = primary_contract()
    result = apply_friday_fee_and_oil(contract, date(2027, 1, 2), date(2027, 1, 8), was_in_possession=False)
    assert not result.eligible
    assert contract.friday_counter == 0

# باب 6 — التحصيل

def test_primary_collection_with_ten_days_arrears():
    contract = primary_contract(total_due=16_500, total_paid=0)
    result = apply_ordinary_collection(
        contract, probability=1.0, master_seed=MASTER_SEED,
        scenario_id="C100_G100", trial_id=1, bike_id="BK1",
        current_date=date(2027, 1, 4), event_type="PRIMARY_COLLECTION",
    )
    assert result.collected == 3_000
    assert result.remaining_outstanding == 13_500


def test_secondary_collection_with_ten_days_arrears():
    contract = secondary_contract(total_due=11_000, total_paid=0)
    result = apply_ordinary_collection(
        contract, probability=1.0, master_seed=MASTER_SEED,
        scenario_id="C100_G100", trial_id=1, bike_id="BK1",
        current_date=date(2027, 2, 6), event_type="SECONDARY_COLLECTION",
    )
    assert result.collected == 2_000
    assert result.remaining_outstanding == 9_000


def test_collection_never_overpays():
    contract = primary_contract(total_due=800, total_paid=0)
    result = apply_ordinary_collection(
        contract, probability=1.0, master_seed=MASTER_SEED,
        scenario_id="C100_G100", trial_id=1, bike_id="BK1",
        current_date=date(2027, 1, 4), event_type="PRIMARY_COLLECTION",
    )
    assert result.collected == 800
    assert contract.total_paid == contract.total_due


def test_collection_does_not_run_on_friday():
    contract = primary_contract(total_due=1_500, total_paid=0)
    result = apply_ordinary_collection(
        contract, probability=1.0, master_seed=MASTER_SEED,
        scenario_id="C100_G100", trial_id=1, bike_id="BK1",
        current_date=date(2027, 1, 8), event_type="PRIMARY_COLLECTION",
    )
    assert not result.success
    assert result.collected == 0
    assert contract.total_paid == 0


def test_collection_probability_zero_is_deterministic_no_rng_needed():
    contract = primary_contract(total_due=1_500, total_paid=0)
    result = apply_ordinary_collection(
        contract, probability=0.0, master_seed=MASTER_SEED,
        scenario_id="C030_G000", trial_id=1, bike_id="BK1",
        current_date=date(2027, 1, 4), event_type="PRIMARY_COLLECTION",
    )
    assert not result.success
    assert result.collected == 0
    assert contract.total_paid == 0


def test_collection_key_is_reproducible():
    args = dict(
        probability=0.5, master_seed=MASTER_SEED,
        scenario_id="C050_G070", trial_id=7, bike_id="BK9",
        current_date=date(2028, 3, 4), event_type="PRIMARY_COLLECTION",
    )
    c1 = primary_contract(total_due=50_000, total_paid=10_000)
    c2 = primary_contract(total_due=50_000, total_paid=10_000)
    r1 = apply_ordinary_collection(c1, **args)
    r2 = apply_ordinary_collection(c2, **args)
    assert r1 == r2

# باب 7 — التسوية

def test_first_settlement_business_day_is_strictly_after_maturity():
    assert first_settlement_business_day_after(date(2029, 1, 2)) == date(2029, 1, 3)
    assert first_settlement_business_day_after(date(2029, 1, 5)) == date(2029, 1, 6)


def test_initialize_settlement_freezes_legacy_debt_on_first_workday():
    b = bike()
    c = primary_contract(total_due=30_000, total_paid=25_000)
    initialize_settlement_on_first_workday(b, c, date(2029, 1, 3))
    assert b.settlement_start_date == date(2029, 1, 3)
    assert b.settlement_legacy_debt_original == 5_000
    assert b.settlement_legacy_debt_remaining == 5_000


def test_settlement_rent_is_deterministic_and_no_ar():
    result = apply_settlement_rent(is_settlement_state=True, current_date=date(2029, 1, 3))
    assert result.applied
    assert result.due == result.collected
    assert result.accounts_receivable_delta == 0


def test_legacy_debt_collection_uses_independent_event_type_and_caps_payment():
    b = bike(settlement_legacy_debt_remaining=1_000)
    r = ReceivableEntry(
        receivable_id="RC1", bike_id="BK1", contract_id="CT1", tenant_id="TN1",
        source="SETTLEMENT_LEGACY_DEBT", original_amount=1_000,
        collected_amount=0, remaining_amount=1_000, status="OUTSTANDING",
        created_date=date(2029, 1, 3),
    )
    result = apply_legacy_debt_collection(
        b, r, probability=1.0, master_seed=MASTER_SEED,
        scenario_id="C100_G100", trial_id=1, bike_id="BK1",
        current_date=date(2029, 1, 3),
    )
    assert result.payment == 1_000
    assert result.remaining_debt == 0
    assert r.status == "SETTLED"


def test_settlement_day_30_does_not_fail_but_day_31_does():
    start = date(2029, 1, 3)
    day30 = start
    business_count = 0
    while business_count < SETTLEMENT_PERIOD_DAYS:
        if day30.weekday() != 4:
            business_count += 1
        if business_count < SETTLEMENT_PERIOD_DAYS:
            day30 += timedelta(days=1)
    status30 = settlement_status(start, day30, 1)
    status31 = settlement_status(start, day30 + timedelta(days=1 if (day30 + timedelta(days=1)).weekday() != 4 else 2), 1)
    assert status30.elapsed_business_days == SETTLEMENT_PERIOD_DAYS
    assert not status30.should_fail
    assert status31.should_fail

# باب 8 — الإهلاك

def test_daily_depreciation_applies_on_possession_day():
    b = bike()
    result = apply_daily_depreciation(b, was_in_possession=True)
    assert result.applied
    assert result.depreciation_amount == 50
    assert b.usage_days == 1
    assert b.accumulated_depreciation == 50


def test_daily_depreciation_skips_without_possession():
    b = bike()
    result = apply_daily_depreciation(b, was_in_possession=False)
    assert not result.applied
    assert b.accumulated_depreciation == 0


def test_daily_depreciation_caps_at_net_book_value():
    b = bike(accumulated_depreciation=BIKE_GROSS_ASSET_COST - 20)
    result = apply_daily_depreciation(b, was_in_possession=True)
    assert result.depreciation_amount == 20
    assert b.net_book_value == 0


def test_ownership_writeoff_uses_bikes_own_gross_cost():
    b = bike(gross_cost=350_000, accumulated_depreciation=12_300, current_state=BikeState.OWNED_TRANSFERRED.value)
    result = apply_ownership_writeoff(b)
    assert result.writeoff_expense == 350_000 - 12_300
    assert result.gross_assets_delta == -350_000
    assert result.remaining_net_book_value == 0
    assert b.accumulated_depreciation == 350_000

# باب 9 — الكفالة

def test_guarantee_waiting_dates_are_stored_at_creation():
    created = date(2027, 1, 15)
    primary = create_guarantee_claim(
        claim_id="CL1", bike_id="BK1", contract_id="CT1", tenant_id="TN1", guarantor_id="GR1",
        claim_source="SECONDARY_EARLY_TERMINATION", claim_amount=15_000,
        created_date=created, recovery_rate_pct=50,
    )
    assert primary.waiting_period_days == 20
    assert primary.settlement_due_date == date(2027, 2, 5)


def test_zero_wait_claim_is_same_day_eligible():
    claim = create_guarantee_claim(
        claim_id="CL2", bike_id="BK1", contract_id="CT2", tenant_id="TN2", guarantor_id="GR2",
        claim_source="FINAL_CLOSURE", claim_amount=4_000,
        created_date=date(2027, 3, 4), recovery_rate_pct=70,
    )
    assert claim.settlement_due_date == claim.created_date
    assert can_settle_claim(claim, claim.created_date)


def test_guarantee_recovery_is_deterministic_percentage():
    claim = create_guarantee_claim(
        claim_id="CL3", bike_id="BK1", contract_id="CT3", tenant_id="TN3", guarantor_id="GR3",
        claim_source="PRIMARY_EARLY_TERMINATION", claim_amount=15_000,
        created_date=date(2027, 1, 10), recovery_rate_pct=50,
    )
    result = settle_guarantee_claim(claim, settlement_date=date(2027, 2, 10))
    assert result.recovered_amount == 7_500
    assert result.bad_debt_amount == 7_500
    assert claim.status == "SETTLED"


def test_guarantee_cannot_be_settled_twice():
    claim = create_guarantee_claim(
        claim_id="CL4", bike_id="BK1", contract_id="CT4", tenant_id="TN4", guarantor_id="GR4",
        claim_source="ADMINISTRATIVE_CLOSURE", claim_amount=10_000,
        created_date=date(2027, 1, 10), recovery_rate_pct=100,
    )
    settle_guarantee_claim(claim, settlement_date=date(2027, 1, 10))
    with pytest.raises(ValueError):
        settle_guarantee_claim(claim, settlement_date=date(2027, 1, 11))


def test_all_reference_recovery_rates_produce_partition_of_claim():
    for rate in (100, 70, 50, 30, 0):
        claim = create_guarantee_claim(
            claim_id=f"CL{rate}", bike_id="BK1", contract_id="CT5", tenant_id="TN5", guarantor_id="GR5",
            claim_source="FINAL_CLOSURE", claim_amount=12_345,
            created_date=date(2027, 1, 10), recovery_rate_pct=rate,
        )
        result = settle_guarantee_claim(claim, settlement_date=date(2027, 1, 10))
        assert result.recovered_amount + result.bad_debt_amount == claim.claim_amount

# Regression: 4.4 lifecycle paths remain intact after adding isolated rules.

def test_reference_lifecycle_paths():
    # 1 normal
    assert derive_state_from_balance(0, 1500, "PRIMARY") == "ACTIVE_PRIMARY"
    assert resolve_primary_maturity("ACTIVE_PRIMARY", current_date=date(2029, 1, 2), maturity_date=date(2029, 1, 2), total_due=360_000, total_paid=360_000) == "OWNED_TRANSFERRED"

    # 2 early primary delinquency
    assert derive_state_from_balance(1_500, 1500, "PRIMARY") == "WAITING_PRIMARY"
    assert derive_state_from_balance(31_500, 1500, "PRIMARY") == "NOTICE_PRIMARY"
    assert derive_state_from_balance(42_000, 1500, "PRIMARY") == "GRACE_PRIMARY"
    assert terminate_for_default("GRACE_PRIMARY", 45_000, "PRIMARY") == "AVAILABLE_FOR_SECONDARY"

    # 3 maturity with debt -> settlement -> ownership
    assert resolve_primary_maturity("ACTIVE_PRIMARY", current_date=date(2029, 1, 2), maturity_date=date(2029, 1, 2), total_due=360_000, total_paid=359_000) == "POST_MATURITY_SETTLEMENT"

    # 4 maturity with debt -> settlement -> failure
    from state_machine import resolve_settlement
    assert resolve_settlement("POST_MATURITY_SETTLEMENT", legacy_debt_remaining=1, settlement_failed=True) == "AVAILABLE_FOR_SECONDARY"

    # 5 repeated secondary
    assert derive_state_from_balance(1_000, 1000, "SECONDARY") == "NOTICE_SECONDARY"
    assert terminate_for_default("NOTICE_SECONDARY", 10_000, "SECONDARY") == "AVAILABLE_FOR_SECONDARY"

    # 6 dynamic closure target
    from state_machine import apply_dynamic_closure
    assert apply_dynamic_closure("ACTIVE_SECONDARY", closure_conditions_met=True) == "HELD_AS_ASSET"
