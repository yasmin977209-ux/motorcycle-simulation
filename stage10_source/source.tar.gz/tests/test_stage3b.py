from datetime import date

from accounting import balance_sheet_snapshot, initialize_accounting, refresh_profit
from closure import closure_preconditions_met, execute_dynamic_closure
from daily_engine import create_initial_project, run_deterministic_trial, run_day
from entities import Project
from partner_equity import record_eligible_inflow, final_entitlements
from constants import TOTAL_CAPITAL, OPENING_RETAINED_LOSS, EXPANSION_CUTOFF_DATE


def test_accounting_opening_balance_is_exactly_zero_difference():
    p = Project()
    initialize_accounting(p)
    snap = balance_sheet_snapshot(p)
    assert snap.total_assets == 3_600_000
    assert snap.total_equity == 3_600_000
    assert snap.balance_difference == 0


def test_partner_memo_tracks_inflow_only_and_final_remainder():
    p = create_initial_project()
    record_eligible_inflow(p, 1_500)
    assert p.partner1_reinvestment_balance == 1_050
    assert p.partner2_reinvestment_balance == 450
    assert final_entitlements(p, 1_001) == (700, 301)


def test_closure_requires_strictly_after_cutoff_and_ignores_pending_claims_as_precondition():
    p = create_initial_project()
    # All initial bikes must be removed from primary/prep/settlement states for this structural test.
    for b in p.bikes:
        b.current_state = "AVAILABLE_FOR_SECONDARY"
    p.guarantee_claims = []
    assert not closure_preconditions_met(p, EXPANSION_CUTOFF_DATE)
    assert closure_preconditions_met(p, date(2031, 1, 1))


def test_one_deterministic_day_keeps_balance_zero_and_order_exact():
    p = create_initial_project()
    result = run_day(p, date(2027, 1, 1), collection_probability=1.0, scenario_id="C100_G100", trial_id=1)
    assert result.balance_difference == 0
    assert p.daily_snapshots[-1]["stage_order"] == tuple(f"M{i}" for i in range(1, 18))
    assert p.daily_balance_checks[-1]["difference"] == 0


def test_deterministic_trial_closes_and_every_day_balances():
    p = run_deterministic_trial(recovery_rate_pct=100, trial_id=1, scenario_id="C100_G100")
    assert p.simulation_stopped
    assert p.final_close_date is not None
    assert p.final_close_date > EXPANSION_CUTOFF_DATE
    assert len(p.daily_balance_checks) == len(p.daily_snapshots)
    assert all(row["difference"] == 0 for row in p.daily_balance_checks)
    assert p.final_net_project_equity is not None
    final_snap = balance_sheet_snapshot(p)
    assert final_snap.balance_difference == 0
    assert final_snap.total_equity == p.final_net_project_equity
    assert p.partner1_final_entitlement + p.partner2_final_entitlement == p.final_net_project_equity
