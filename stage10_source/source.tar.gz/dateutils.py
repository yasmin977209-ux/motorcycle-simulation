from datetime import date, timedelta
from dateutil.relativedelta import relativedelta

from constants import BIKE_PREP_SCHEDULE_DAYS, PRIMARY_CONTRACT_MONTHS


def is_business_day(day: date) -> bool:
    """أيام العمل هي كل الأيام عدا الجمعة."""
    return day.weekday() != 4


def next_business_day_on_or_after(day: date) -> date:
    while not is_business_day(day):
        day += timedelta(days=1)
    return day


def scheduled_ready_date(purchase_date: date) -> date:
    return purchase_date + timedelta(days=BIKE_PREP_SCHEDULE_DAYS)


def delivery_date(actual_ready_date: date) -> date:
    return next_business_day_on_or_after(actual_ready_date)


def primary_maturity_date(start_date: date) -> date:
    return start_date + relativedelta(months=PRIMARY_CONTRACT_MONTHS)


def settlement_due_date(created_date: date, waiting_period_days: int) -> date:
    if waiting_period_days == 0:
        return created_date
    return created_date + timedelta(days=waiting_period_days + 1)


def first_friday_on_or_after(day: date) -> date:
    days_ahead = (4 - day.weekday()) % 7
    return day + timedelta(days=days_ahead)


def eligible_friday(delivery_or_contract_start: date, current_date: date) -> bool:
    """تطبيق البند 5.2: سبت/أحد/اثنين: الجمعة التالية مؤهلة؛ ثلاثاء/أربعاء/خميس: الجمعة التالية معفاة."""
    if current_date.weekday() != 4 or current_date <= delivery_or_contract_start:
        return False
    first = first_friday_on_or_after(delivery_or_contract_start)
    if first == delivery_or_contract_start:
        first += timedelta(days=7)
    if delivery_or_contract_start.weekday() in (5, 6, 0):
        eligible_first = first
    elif delivery_or_contract_start.weekday() in (1, 2, 3):
        eligible_first = first + timedelta(days=7)
    else:
        return False
    return current_date >= eligible_first and (current_date - eligible_first).days % 7 == 0


def friday_counter_for_date(delivery_or_contract_start: date, current_date: date) -> int:
    if current_date < delivery_or_contract_start or current_date.weekday() != 4:
        return 0
    first = first_friday_on_or_after(delivery_or_contract_start)
    if delivery_or_contract_start.weekday() in (5, 6, 0):
        eligible_first = first
    elif delivery_or_contract_start.weekday() in (1, 2, 3):
        eligible_first = first + timedelta(days=7)
    else:
        return 0
    if current_date < eligible_first:
        return 0
    return ((current_date - eligible_first).days // 7) + 1


def count_business_days(start_date: date, end_date: date) -> int:
    """عدد أيام العمل من start_date إلى end_date شاملين إذا كانا يومي عمل."""
    if end_date < start_date:
        return 0
    count = 0
    cursor = start_date
    while cursor <= end_date:
        if is_business_day(cursor):
            count += 1
        cursor += timedelta(days=1)
    return count
