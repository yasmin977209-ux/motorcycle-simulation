"""Chapter 10 — accounting state and double-entry-style balance updates."""
from __future__ import annotations
from dataclasses import dataclass
from entities import Project
from constants import (
    TOTAL_CAPITAL, OPENING_RETAINED_LOSS, OPENING_BIKE_ASSETS, OPENING_CASH,
)


@dataclass(frozen=True)
class AccountingSnapshot:
    cash: int
    accounts_receivable: int
    guarantee_claim_receivable: int
    gross_bike_assets: int
    accumulated_depreciation: int
    net_bike_assets: int
    total_assets: int
    capital: int
    retained_earnings: int
    total_equity: int
    liabilities: int
    balance_difference: int


def initialize_accounting(project: Project) -> None:
    project.project_cash = OPENING_CASH
    project.accounts_receivable = 0
    project.guarantee_claim_receivable = 0
    project.gross_bike_assets = OPENING_BIKE_ASSETS
    project.accumulated_depreciation_project = 0
    project.capital = TOTAL_CAPITAL
    project.retained_earnings = OPENING_RETAINED_LOSS
    project.revenue_primary = 0
    project.revenue_secondary = 0
    project.revenue_settlement = 0
    project.revenue_friday_fee = 0
    project.expense_depreciation = 0
    project.expense_oil_service = 0
    project.expense_prep = 0
    project.expense_marketing = 0
    project.bad_debt_expense = 0
    project.asset_writeoff_expense = 0
    project.operating_revenue = 0
    project.operating_expenses = 0
    project.operating_net_profit = 0
    project.cumulative_project_profit = OPENING_RETAINED_LOSS
    project.daily_operating_net_profit = 0
    project.daily_balance_difference = 0
    project.daily_balance_checks = []
    project.daily_snapshots = []
    assert balance_sheet_snapshot(project).balance_difference == 0


def accrue_rent(project: Project, *, contract_type: str, amount: int) -> None:
    if amount < 0:
        raise ValueError("rent accrual cannot be negative")
    project.accounts_receivable += amount
    if contract_type == "PRIMARY":
        project.revenue_primary += amount
    elif contract_type == "SECONDARY":
        project.revenue_secondary += amount
    else:
        raise ValueError(f"unsupported contract type: {contract_type}")


def collect_from_ar(project: Project, amount: int) -> None:
    if amount < 0 or amount > project.accounts_receivable:
        raise ValueError("invalid AR collection")
    project.project_cash += amount
    project.accounts_receivable -= amount


def record_settlement_rent(project: Project, amount: int) -> None:
    if amount < 0:
        raise ValueError("settlement rent cannot be negative")
    project.project_cash += amount
    project.revenue_settlement += amount


def record_friday_fee(project: Project, amount: int) -> None:
    if amount < 0:
        raise ValueError("Friday fee cannot be negative")
    project.project_cash += amount
    project.revenue_friday_fee += amount


def record_oil_service(project: Project, amount: int) -> None:
    if amount < 0:
        raise ValueError("oil expense cannot be negative")
    if amount > project.project_cash:
        raise ValueError("insufficient cash for oil service")
    project.project_cash -= amount
    project.expense_oil_service += amount


def record_prep_expense(project: Project, amount: int) -> None:
    if amount < 0:
        raise ValueError("prep expense cannot be negative")
    if amount > project.project_cash:
        raise ValueError("insufficient cash for prep expense")
    project.project_cash -= amount
    project.expense_prep += amount


def record_purchase(project: Project, amount: int) -> None:
    if amount < 0 or amount > project.project_cash:
        raise ValueError("invalid expansion purchase")
    project.project_cash -= amount
    project.gross_bike_assets += amount


def record_customs_registration(project: Project, amount: int) -> None:
    if amount < 0 or amount > project.project_cash:
        raise ValueError("invalid customs/registration payment")
    project.project_cash -= amount
    project.gross_bike_assets += amount


def record_depreciation(project: Project, amount: int) -> None:
    if amount < 0:
        raise ValueError("depreciation cannot be negative")
    project.accumulated_depreciation_project += amount
    project.expense_depreciation += amount


def transfer_ar_to_guarantee(project: Project, amount: int) -> None:
    if amount < 0 or amount > project.accounts_receivable:
        raise ValueError("invalid AR-to-guarantee transfer")
    project.accounts_receivable -= amount
    project.guarantee_claim_receivable += amount


def settle_guarantee_accounting(project: Project, claim_amount: int, recovered: int, bad_debt: int) -> None:
    if claim_amount < 0 or recovered < 0 or bad_debt < 0 or recovered + bad_debt != claim_amount:
        raise ValueError("invalid guarantee settlement amounts")
    if claim_amount > project.guarantee_claim_receivable:
        raise ValueError("guarantee receivable underflow")
    project.project_cash += recovered
    project.guarantee_claim_receivable -= claim_amount
    project.bad_debt_expense += bad_debt


def record_asset_writeoff(project: Project, gross_cost: int, old_accumulated: int) -> None:
    if gross_cost < 0 or old_accumulated < 0 or old_accumulated > gross_cost:
        raise ValueError("invalid asset writeoff")
    project.accumulated_depreciation_project -= old_accumulated
    project.gross_bike_assets -= gross_cost
    project.asset_writeoff_expense += gross_cost - old_accumulated
    if project.gross_bike_assets < 0 or project.accumulated_depreciation_project < 0:
        raise ValueError("asset account underflow")


def refresh_profit(project: Project) -> None:
    project.operating_revenue = (
        project.revenue_primary + project.revenue_secondary
        + project.revenue_settlement + project.revenue_friday_fee
    )
    project.operating_expenses = (
        project.expense_depreciation + project.expense_oil_service
        + project.expense_prep + project.bad_debt_expense
        + project.asset_writeoff_expense
    )
    project.operating_net_profit = project.operating_revenue - project.operating_expenses
    project.cumulative_project_profit = OPENING_RETAINED_LOSS + project.operating_net_profit
    project.retained_earnings = project.cumulative_project_profit


def balance_sheet_snapshot(project: Project) -> AccountingSnapshot:
    net_bike_assets = project.gross_bike_assets - project.accumulated_depreciation_project
    total_assets = (
        project.project_cash + project.accounts_receivable
        + project.guarantee_claim_receivable + net_bike_assets
    )
    total_equity = project.capital + project.retained_earnings
    difference = total_assets - total_equity
    return AccountingSnapshot(
        cash=project.project_cash,
        accounts_receivable=project.accounts_receivable,
        guarantee_claim_receivable=project.guarantee_claim_receivable,
        gross_bike_assets=project.gross_bike_assets,
        accumulated_depreciation=project.accumulated_depreciation_project,
        net_bike_assets=net_bike_assets,
        total_assets=total_assets,
        capital=project.capital,
        retained_earnings=project.retained_earnings,
        total_equity=total_equity,
        liabilities=0,
        balance_difference=difference,
    )


def finalize_daily_accounting(project: Project, *, current_date, stage_order: tuple[str, ...]) -> AccountingSnapshot:
    refresh_profit(project)
    snap = balance_sheet_snapshot(project)
    project.daily_balance_difference = snap.balance_difference
    project.daily_balance_checks.append({"date": current_date, "difference": snap.balance_difference})
    project.daily_snapshots.append({
        "date": current_date,
        "stage_order": stage_order,
        "cash": snap.cash,
        "accounts_receivable": snap.accounts_receivable,
        "guarantee_claim_receivable": snap.guarantee_claim_receivable,
        "gross_bike_assets": snap.gross_bike_assets,
        "accumulated_depreciation": snap.accumulated_depreciation,
        "net_bike_assets": snap.net_bike_assets,
        "total_assets": snap.total_assets,
        "capital": snap.capital,
        "retained_earnings": snap.retained_earnings,
        "total_equity": snap.total_equity,
        "difference": snap.balance_difference,
    })
    if snap.balance_difference != 0:
        raise AssertionError(f"Assets != Equity on {current_date}: difference={snap.balance_difference}")
    return snap
