"""Entities for the motorcycle simulation.

Stage 2 scope: Chapters 3 only.  The classes are data entities; daily business
processing remains outside this module.

All material fields below follow the binding reference, Chapters 3.1–3.8.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from typing import Optional

from constants import (
    BIKE_STATES,
    CLAIM_SOURCES,
    CLAIM_STATUSES,
    CONTRACT_STATUSES,
    CONTRACT_TYPES,
    EVENT_TYPES,
    RECEIVABLE_STATUSES,
    TENANT_TYPES,
)


@dataclass
class Bike:
    """Chapter 3.2 — one motorcycle."""

    bike_id: str
    source: str
    purchase_date: date
    scheduled_ready_date: date
    funding_completion_date: Optional[date] = None
    actual_ready_date: Optional[date] = None
    prep_paid: bool = False
    customs_paid: bool = False
    delivery_date: Optional[date] = None
    gross_cost: int = 0
    accumulated_depreciation: int = 0
    current_state: str = "PREP"
    current_contract_id: Optional[str] = None
    current_tenant_id: Optional[str] = None
    settlement_start_date: Optional[date] = None
    settlement_legacy_debt_original: Optional[int] = None
    settlement_legacy_debt_remaining: Optional[int] = None
    settlement_business_days_elapsed: int = 0
    settlement_rent_due_total: int = 0
    settlement_rent_collected_total: int = 0
    termination_count: int = 0
    secondary_cycle_count: int = 0
    usage_days: int = 0
    lifecycle_cycle_number: int = 1
    lifecycle_history: list["EventLogEntry"] = field(default_factory=list)
    receivables_ledger: list["ReceivableEntry"] = field(default_factory=list)

    @property
    def net_book_value(self) -> int:
        """Chapter 3.2: max(0, gross_cost - accumulated_depreciation)."""
        return max(0, self.gross_cost - self.accumulated_depreciation)

    def __post_init__(self) -> None:
        if self.source not in {"INITIAL", "EXPANSION"}:
            raise ValueError(f"Invalid bike source: {self.source}")
        if self.current_state not in BIKE_STATES:
            raise ValueError(f"Invalid bike state: {self.current_state}")
        if not isinstance(self.gross_cost, int) or isinstance(self.gross_cost, bool):
            raise TypeError("gross_cost must be int")
        if not isinstance(self.accumulated_depreciation, int) or isinstance(
            self.accumulated_depreciation, bool
        ):
            raise TypeError("accumulated_depreciation must be int")
        if any(
            hasattr(self, deprecated)
            for deprecated in (
                "notice_start_date",
                "grace_start_date",
                "legacy_debt_amount",
                "mini_prep_date",
            )
        ):
            raise ValueError("Deprecated bike fields are forbidden")


@dataclass
class Contract:
    """Chapter 3.3 — source of truth for due/paid/friday_counter."""

    contract_id: str
    bike_id: str
    tenant_id: str
    guarantor_id: str
    contract_type: str
    daily_rate: int
    start_date: date
    maturity_date: Optional[date] = None
    status: str = "ACTIVE"
    total_due: int = 0
    total_paid: int = 0
    friday_counter: int = 0

    def __post_init__(self) -> None:
        if self.contract_type not in CONTRACT_TYPES:
            raise ValueError(f"Invalid contract type: {self.contract_type}")
        if self.status not in CONTRACT_STATUSES:
            raise ValueError(f"Invalid contract status: {self.status}")
        if not isinstance(self.daily_rate, int) or isinstance(self.daily_rate, bool):
            raise TypeError("daily_rate must be int")
        for value_name in ("total_due", "total_paid", "friday_counter"):
            value = getattr(self, value_name)
            if not isinstance(value, int) or isinstance(value, bool):
                raise TypeError(f"{value_name} must be int")


@dataclass
class Tenant:
    """Chapter 3.4 — a new tenant entity per contract cycle."""

    tenant_id: str
    tenant_type: str
    contract_id: str
    guarantor_id: str
    start_date: date
    end_date: Optional[date] = None

    def __post_init__(self) -> None:
        if self.tenant_type not in TENANT_TYPES:
            raise ValueError(f"Invalid tenant type: {self.tenant_type}")


@dataclass
class Guarantor:
    """Chapter 3.5 — one guarantor per new contract."""

    guarantor_id: str
    related_contract_id: str
    related_tenant_id: str


@dataclass
class GuaranteeClaim:
    """Chapter 3.6 — deterministic guarantee claim."""

    claim_id: str
    bike_id: str
    contract_id: str
    tenant_id: str
    guarantor_id: str
    claim_source: str
    claim_amount: int
    created_date: date
    waiting_period_days: int
    settlement_due_date: date
    recovery_rate_pct: int
    settlement_date: Optional[date] = None
    recovered_amount: Optional[int] = None
    bad_debt_amount: Optional[int] = None
    status: str = "PENDING"

    def __post_init__(self) -> None:
        if self.claim_source not in CLAIM_SOURCES:
            raise ValueError(f"Invalid claim source: {self.claim_source}")
        if self.status not in CLAIM_STATUSES:
            raise ValueError(f"Invalid claim status: {self.status}")
        if self.recovery_rate_pct not in {100, 70, 50, 30, 0}:
            raise ValueError("recovery_rate_pct must be one of 100/70/50/30/0")
        for value_name in (
            "claim_amount",
            "waiting_period_days",
            "recovery_rate_pct",
        ):
            value = getattr(self, value_name)
            if not isinstance(value, int) or isinstance(value, bool):
                raise TypeError(f"{value_name} must be int")

    def settle_deterministically(self, settlement_date: date) -> None:
        """Chapter 9.1 formula; no RNG."""
        self.recovered_amount = (self.claim_amount * self.recovery_rate_pct) // 100
        self.bad_debt_amount = self.claim_amount - self.recovered_amount
        self.settlement_date = settlement_date
        self.status = "SETTLED"


@dataclass
class ReceivableEntry:
    """Chapter 3.7 — detail ledger for settlement legacy debt only."""

    receivable_id: str
    bike_id: str
    contract_id: str
    tenant_id: str
    source: str
    original_amount: int
    collected_amount: int
    remaining_amount: int
    status: str
    created_date: date
    settlement_date: Optional[date] = None

    def __post_init__(self) -> None:
        if self.source != "SETTLEMENT_LEGACY_DEBT":
            raise ValueError("ReceivableEntry.source must be SETTLEMENT_LEGACY_DEBT")
        if self.status not in RECEIVABLE_STATUSES:
            raise ValueError(f"Invalid receivable status: {self.status}")


@dataclass
class EventLogEntry:
    """Chapter 3.8 — one immutable-style business event record."""

    event_id: str
    date: date
    bike_id: str
    event_type: str
    previous_state: Optional[str] = None
    new_state: Optional[str] = None
    contract_id: Optional[str] = None
    tenant_id: Optional[str] = None
    guarantor_id: Optional[str] = None
    receivable_id: Optional[str] = None
    claim_id: Optional[str] = None
    amount_if_applicable: Optional[int] = None
    balance_before: Optional[int] = None
    balance_after: Optional[int] = None
    trigger_reason: str = ""
    notes: str = ""

    def __post_init__(self) -> None:
        if self.event_type not in EVENT_TYPES:
            raise ValueError(f"Invalid event type: {self.event_type}")
        if self.previous_state is not None and self.previous_state not in BIKE_STATES:
            raise ValueError(f"Invalid previous state: {self.previous_state}")
        if self.new_state is not None and self.new_state not in BIKE_STATES:
            raise ValueError(f"Invalid new state: {self.new_state}")
        if self.amount_if_applicable is not None and (
            not isinstance(self.amount_if_applicable, int)
            or isinstance(self.amount_if_applicable, bool)
        ):
            raise TypeError("amount_if_applicable must be int or None")


@dataclass
class Project:
    """Chapter 3.1 — unified economic entity.

    These are the explicit project-level stores named by the reference.
    Partner memo balances are outside the balance sheet.
    """

    project_cash: int = 0
    partner1_reinvestment_balance: int = 0
    partner2_reinvestment_balance: int = 0
    bikes: list[Bike] = field(default_factory=list)
    contracts: list[Contract] = field(default_factory=list)
    tenants: list[Tenant] = field(default_factory=list)
    guarantors: list[Guarantor] = field(default_factory=list)
    guarantee_claims: list[GuaranteeClaim] = field(default_factory=list)
    receivables: list[ReceivableEntry] = field(default_factory=list)
    event_log: list[EventLogEntry] = field(default_factory=list)

    def __post_init__(self) -> None:
        for field_name in (
            "project_cash",
            "partner1_reinvestment_balance",
            "partner2_reinvestment_balance",
        ):
            value = getattr(self, field_name)
            if not isinstance(value, int) or isinstance(value, bool):
                raise TypeError(f"{field_name} must be int")
        if self.project_cash < 0:
            raise ValueError("project_cash cannot be negative")
        if self.partner1_reinvestment_balance < 0:
            raise ValueError("partner1_reinvestment_balance cannot be negative")
        if self.partner2_reinvestment_balance < 0:
            raise ValueError("partner2_reinvestment_balance cannot be negative")
