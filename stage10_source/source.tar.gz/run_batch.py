"""Stage 8 — adaptive batch orchestration with atomic state and SHA-256 manifest.

This module orchestrates already-validated trial execution from ``monte_carlo.py``.
It does not modify the daily simulation engine. Production defaults follow the
reference starting points and escalation schedule; small demo runs are explicit
CLI-only test controls and never change the production defaults.
"""
from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
from math import sqrt
import os
from pathlib import Path
import tempfile
from typing import Any, Iterable

import numpy as np
from scipy.stats import t as student_t

from constants import COLLECTION_PROBABILITIES, GUARANTEE_RECOVERY_RATES
from monte_carlo import TrialResult, run_trial, scenario_id, trial_fingerprint

REFERENCE_ABSOLUTE_EPSILON = 1
REFERENCE_EPSILON = 1e-6

START_REPETITIONS: dict[float, int] = {
    1.00: 200,
    0.85: 5_000,
    0.70: 8_000,
    0.50: 15_000,
    0.30: 20_000,
}

REFERENCE_ESCALATION = (20_000, 40_000, 80_000, 100_000, 200_000)


class BatchStateError(RuntimeError):
    """Raised when persisted batch state is structurally invalid."""


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def canonical_json_bytes(payload: Any) -> bytes:
    return json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def sha256_bytes(blob: bytes) -> str:
    return hashlib.sha256(blob).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def atomic_write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp_path, path)
        try:
            dir_fd = os.open(path.parent, os.O_RDONLY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except OSError:
            # Filesystems that do not expose fsync on directories still get the
            # atomic replace guarantee from os.replace().
            pass
    finally:
        if tmp_path.exists():
            tmp_path.unlink()


def atomic_write_json(path: Path, payload: Any) -> None:
    atomic_write_bytes(path, canonical_json_bytes(payload) + b"\n")


def next_checkpoint_size(current_size: int, collection_probability: float) -> int:
    """Return the next reference escalation point, without imposing a ceiling."""
    if current_size < REFERENCE_ESCALATION[0]:
        return min(current_size * 2, REFERENCE_ESCALATION[0])
    if current_size < REFERENCE_ESCALATION[1]:
        return REFERENCE_ESCALATION[1]
    if current_size < REFERENCE_ESCALATION[2]:
        return REFERENCE_ESCALATION[2]
    if current_size < REFERENCE_ESCALATION[3]:
        return REFERENCE_ESCALATION[3]
    if current_size < REFERENCE_ESCALATION[4]:
        return REFERENCE_ESCALATION[4]
    return current_size * 2


def reference_start_repetitions(collection_probability: float) -> int:
    try:
        return START_REPETITIONS[float(collection_probability)]
    except KeyError as exc:
        raise ValueError("collection_probability is outside the 5-level reference matrix") from exc


def reference_is_stable(old_value: float, new_value: float) -> bool:
    if abs(old_value) < REFERENCE_EPSILON:
        return abs(new_value - old_value) < REFERENCE_ABSOLUTE_EPSILON
    return abs(new_value - old_value) / abs(old_value) < 0.01


def quantile(arr: np.ndarray, q: float) -> float:
    return float(np.quantile(arr, q, method="linear"))


def checkpoint_metrics(trials: Iterable[TrialResult]) -> dict[str, float | int]:
    values = list(trials)
    if not values:
        raise ValueError("checkpoint requires at least one completed trial")
    profit = np.asarray([t.cumulative_project_profit for t in values], dtype=np.float64)
    final_cash = np.asarray([t.final_cash for t in values], dtype=np.float64)
    terminations = np.asarray([t.termination_count for t in values], dtype=np.float64)
    held_assets = np.asarray([t.held_assets for t in values], dtype=np.float64)
    return {
        "n": len(values),
        "p10_cumulative_project_profit": quantile(profit, 0.10),
        "p50_cumulative_project_profit": quantile(profit, 0.50),
        "p90_cumulative_project_profit": quantile(profit, 0.90),
        "p90_final_cash": quantile(final_cash, 0.90),
        "probability_of_loss": float(np.mean(profit < 0.0)),
        "p90_termination_count": quantile(terminations, 0.90),
        "p90_held_assets": quantile(held_assets, 0.90),
    }


def reference_stability_gate(old: dict[str, float] | None, new: dict[str, float]) -> dict[str, Any]:
    if old is None:
        return {
            "stable": False,
            "comparable": False,
            "reason": "first_checkpoint_has_no_previous_checkpoint",
        }
    keys = (
        "p10_cumulative_project_profit",
        "p50_cumulative_project_profit",
        "p90_cumulative_project_profit",
        "p90_final_cash",
        "probability_of_loss",
        "p90_termination_count",
        "p90_held_assets",
    )
    details = {key: reference_is_stable(float(old[key]), float(new[key])) for key in keys}
    return {
        "stable": all(details.values()),
        "comparable": True,
        "details": details,
        "reason": "all_reference_metrics_stable" if all(details.values()) else "one_or_more_reference_metrics_changed",
    }


def final_entitlements(equity: int) -> tuple[int, int]:
    partner1 = (equity * 70) // 100
    partner2 = equity - partner1
    return partner1, partner2


def ci95_half_width(values: Iterable[float]) -> tuple[float, float, float]:
    arr = np.asarray(list(values), dtype=np.float64)
    n = int(arr.size)
    if n < 2:
        return float("nan"), float(arr.mean()) if n else float("nan"), float("nan")
    mean = float(arr.mean())
    sample_std = float(arr.std(ddof=1))
    critical = float(student_t.ppf(0.975, df=n - 1))
    half_width = critical * sample_std / sqrt(n)
    return half_width, mean, critical


def project_ci_gate(trials: Iterable[TrialResult]) -> dict[str, Any]:
    values = list(trials)
    n = len(values)
    if n < 300:
        return {
            "pass": False,
            "eligible": False,
            "n": n,
            "reason": "minimum_300_repetitions_not_reached",
        }

    equity = [float(t.final_net_project_equity) for t in values]
    p1 = [float(final_entitlements(int(t.final_net_project_equity))[0]) for t in values]
    p2 = [float(final_entitlements(int(t.final_net_project_equity))[1]) for t in values]

    checks: dict[str, Any] = {}
    for label, series in (("Final_Net_Equity", equity), ("P1", p1), ("P2", p2)):
        half_width, mean, critical = ci95_half_width(series)
        threshold = (
            REFERENCE_ABSOLUTE_EPSILON
            if abs(mean) < REFERENCE_EPSILON
            else 0.01 * abs(mean)
        )
        checks[label] = {
            "mean": mean,
            "ci95_half_width": half_width,
            "threshold": threshold,
            "critical_t": critical,
            "pass": bool(half_width < threshold),
        }
    return {
        "pass": all(v["pass"] for v in checks.values()),
        "eligible": True,
        "n": n,
        "checks": checks,
    }


def serialize_trial(trial: TrialResult) -> dict[str, Any]:
    payload = asdict(trial)
    return payload


def write_trial_file(trial: TrialResult, output_dir: Path) -> tuple[Path, str, str]:
    trials_dir = output_dir / "trials"
    trials_dir.mkdir(parents=True, exist_ok=True)
    path = trials_dir / f"{trial.scenario_id}_trial_{trial.trial_id:06d}.json"
    payload = serialize_trial(trial)
    atomic_write_json(path, payload)
    return path, sha256_file(path), trial_fingerprint(trial)


def canonical_manifest_body(manifest: dict[str, Any]) -> dict[str, Any]:
    body = dict(manifest)
    body.pop("manifest_sha256", None)
    return body


def finalize_manifest(manifest: dict[str, Any]) -> dict[str, Any]:
    body = canonical_manifest_body(manifest)
    manifest["manifest_sha256"] = sha256_bytes(canonical_json_bytes(body))
    return manifest


def save_manifest(output_dir: Path, manifest: dict[str, Any]) -> None:
    finalized = finalize_manifest(dict(manifest))
    manifest_path = output_dir / "manifest.json"
    atomic_write_json(manifest_path, finalized)
    atomic_write_json(output_dir / "manifest.sha256.json", {"sha256": sha256_file(manifest_path)})


def default_state(scenarios: list[str]) -> dict[str, Any]:
    return {
        "stage": 8,
        "status": "initialized",
        "created_at": utc_now(),
        "updated_at": utc_now(),
        "scenarios": {scenario: {"completed_trial_ids": [], "checkpoints": [], "reference_stable": False,
                                 "project_ci_stable": False, "consecutive_project_ci_passes": 0,
                                 "complete": False} for scenario in scenarios},
    }


def load_json(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise BatchStateError(f"could not read JSON state: {path}") from exc


def save_state(output_dir: Path, state: dict[str, Any]) -> None:
    state["updated_at"] = utc_now()
    atomic_write_json(output_dir / "state.json", state)


def load_or_create_state(output_dir: Path, scenarios: list[str]) -> dict[str, Any]:
    path = output_dir / "state.json"
    if not path.exists():
        state = default_state(scenarios)
        save_state(output_dir, state)
        return state
    state = load_json(path)
    if state.get("stage") != 8:
        raise BatchStateError("state.json belongs to a different stage")
    state.setdefault("scenarios", {})
    for scenario in scenarios:
        state["scenarios"].setdefault(
            scenario,
            {"completed_trial_ids": [], "checkpoints": [], "reference_stable": False,
             "project_ci_stable": False, "consecutive_project_ci_passes": 0, "complete": False},
        )
    return state


def load_trials_from_manifest(output_dir: Path, scenario: str) -> list[TrialResult]:
    manifest_path = output_dir / "manifest.json"
    if not manifest_path.exists():
        return []
    manifest = load_json(manifest_path)
    trials: list[TrialResult] = []
    for row in manifest.get("trials", []):
        if row.get("scenario_id") != scenario:
            continue
        trial_path = output_dir / row["relative_path"]
        payload = load_json(trial_path)
        payload["daily_snapshots"] = tuple()
        payload["event_log"] = tuple()
        payload["contracts"] = tuple()
        payload["guarantee_claims"] = tuple()
        payload["assets"] = tuple()
        trials.append(TrialResult(**payload))
    return sorted(trials, key=lambda trial: trial.trial_id)


def update_manifest_from_trial(output_dir: Path, manifest: dict[str, Any], trial: TrialResult,
                               path: Path, file_sha256: str, fingerprint: str) -> None:
    rows = list(manifest.get("trials", []))
    existing = next((r for r in rows if r["scenario_id"] == trial.scenario_id and r["trial_id"] == trial.trial_id), None)
    if existing is not None:
        raise BatchStateError(f"attempt to duplicate completed trial {trial.scenario_id}#{trial.trial_id}")
    rows.append({
        "scenario_id": trial.scenario_id,
        "trial_id": trial.trial_id,
        "final_close_date": trial.final_close_date,
        "final_net_project_equity": trial.final_net_project_equity,
        "final_cash": trial.final_cash,
        "file_sha256": file_sha256,
        "trial_fingerprint": fingerprint,
        "relative_path": str(path.relative_to(output_dir)),
        "execution_count": 1,
        "recorded_at": utc_now(),
    })
    rows.sort(key=lambda r: (r["scenario_id"], r["trial_id"]))
    manifest["trials"] = rows
    manifest["trial_count"] = len(rows)
    manifest["updated_at"] = utc_now()
    save_manifest(output_dir, manifest)


def new_manifest(output_dir: Path) -> dict[str, Any]:
    path = output_dir / "manifest.json"
    if path.exists():
        manifest = load_json(path)
        verify_manifest(output_dir, manifest)
        return manifest
    manifest = {
        "stage": 8,
        "format": "stage8-batch-manifest-v1",
        "created_at": utc_now(),
        "updated_at": utc_now(),
        "trial_count": 0,
        "trials": [],
    }
    save_manifest(output_dir, manifest)
    return manifest


def verify_manifest(output_dir: Path, manifest: dict[str, Any]) -> None:
    expected = manifest.get("manifest_sha256")
    actual = sha256_bytes(canonical_json_bytes(canonical_manifest_body(manifest)))
    if expected != actual:
        raise BatchStateError("manifest_sha256 does not match its canonical body")
    for row in manifest.get("trials", []):
        path = output_dir / row["relative_path"]
        if sha256_file(path) != row["file_sha256"]:
            raise BatchStateError(f"trial artifact sha256 mismatch: {path}")


def apply_checkpoint(state_scenario: dict[str, Any], trials: list[TrialResult]) -> None:
    if not trials:
        return
    metrics = checkpoint_metrics(trials)
    checkpoints = list(state_scenario.get("checkpoints", []))
    previous = checkpoints[-1]["metrics"] if checkpoints else None
    reference_gate = reference_stability_gate(previous, metrics)
    ci_gate = project_ci_gate(trials)
    if ci_gate["eligible"] and ci_gate["pass"]:
        consecutive = int(state_scenario.get("consecutive_project_ci_passes", 0)) + 1
    else:
        consecutive = 0
    state_scenario["consecutive_project_ci_passes"] = consecutive
    state_scenario["reference_stable"] = bool(reference_gate["stable"])
    state_scenario["project_ci_stable"] = consecutive >= 3
    checkpoints.append({
        "n": int(metrics["n"]),
        "metrics": metrics,
        "reference_gate": reference_gate,
        "project_ci_gate": ci_gate,
        "project_ci_consecutive_passes": consecutive,
        "recorded_at": utc_now(),
    })
    state_scenario["checkpoints"] = checkpoints


def initial_checkpoint(collection_probability: float, demo_total: int | None) -> int:
    if demo_total is not None:
        if demo_total < 1:
            raise ValueError("demo_total must be >= 1")
        return demo_total
    return reference_start_repetitions(collection_probability)


def next_target_from_state(collection_probability: float, completed_count: int,
                           scenario_state: dict[str, Any], demo_total: int | None) -> int:
    if demo_total is not None:
        return demo_total
    checkpoints = list(scenario_state.get("checkpoints", []))
    if not checkpoints:
        return initial_checkpoint(collection_probability, None)
    last_n = int(checkpoints[-1]["n"])
    return next_checkpoint_size(last_n, collection_probability)


def run_scenario_batch(collection_probability: float, recovery_rate_pct: int, output_dir: Path,
                       *, demo_total: int | None = None, stop_after_new_trials: int | None = None,
                       keep_daily: bool = False, include_raw_logs: bool = False) -> dict[str, Any]:
    scenario = scenario_id(collection_probability, recovery_rate_pct)
    state = load_or_create_state(output_dir, [scenario])
    manifest = new_manifest(output_dir)
    scenario_state = state["scenarios"][scenario]
    completed = set(int(x) for x in scenario_state.get("completed_trial_ids", []))
    manifest_completed = {int(r["trial_id"]) for r in manifest.get("trials", []) if r["scenario_id"] == scenario}
    completed |= manifest_completed
    scenario_state["completed_trial_ids"] = sorted(completed)

    all_trials = load_trials_from_manifest(output_dir, scenario)
    if len(all_trials) != len(completed):
        raise BatchStateError("state.json and manifest disagree on completed trial count")

    # Recover a checkpoint that was fully materialized in the manifest but whose
    # state write was interrupted. This is intentionally idempotent.
    target_count = next_target_from_state(collection_probability, len(all_trials), scenario_state, demo_total)
    recorded_n = int(scenario_state.get("checkpoints", [{}])[-1].get("n", 0)) if scenario_state.get("checkpoints") else 0
    if demo_total is not None and len(all_trials) >= target_count and recorded_n < target_count:
        apply_checkpoint(scenario_state, all_trials)
        recorded_n = target_count
        save_state(output_dir, state)

    new_trials = 0
    while True:
        target_count = next_target_from_state(collection_probability, len(all_trials), scenario_state, demo_total)
        if len(all_trials) >= target_count:
            # Production completion requires both stability gates. A demo target
            # is deliberately only a smoke target; it cannot assert stability.
            reference_ok = bool(scenario_state["reference_stable"])
            project_ok = bool(scenario_state["project_ci_stable"])
            if demo_total is not None or (reference_ok and project_ok):
                break
            target_count = next_checkpoint_size(target_count, collection_probability)

        trial_id = max(completed, default=0) + 1
        trial = run_trial(
            collection_probability,
            recovery_rate_pct,
            trial_id,
            scenario,
            keep_daily=keep_daily,
            include_raw_logs=include_raw_logs,
        )
        trial_path, file_hash, fingerprint = write_trial_file(trial, output_dir)
        update_manifest_from_trial(output_dir, manifest, trial, trial_path, file_hash, fingerprint)
        all_trials.append(trial)
        all_trials.sort(key=lambda item: item.trial_id)
        completed.add(trial_id)
        scenario_state["completed_trial_ids"] = sorted(completed)

        if len(all_trials) >= target_count:
            apply_checkpoint(scenario_state, all_trials)
            scenario_state["next_checkpoint_target"] = (
                None if (demo_total is not None or
                         (scenario_state["reference_stable"] and scenario_state["project_ci_stable"]))
                else next_checkpoint_size(target_count, collection_probability)
            )
        save_state(output_dir, state)
        new_trials += 1

        if stop_after_new_trials is not None and new_trials >= stop_after_new_trials:
            state["status"] = "intentionally_stopped"
            save_state(output_dir, state)
            return {
                "scenario_id": scenario,
                "status": "intentionally_stopped",
                "completed_trials": len(completed),
                "new_trials": new_trials,
                "target_trials": target_count,
                "reference_stable": bool(scenario_state["reference_stable"]),
                "project_ci_stable": bool(scenario_state["project_ci_stable"]),
            }

    stable = bool(scenario_state["reference_stable"] and scenario_state["project_ci_stable"])
    state["status"] = "stable" if stable else "target_reached_demo"
    scenario_state["complete"] = stable
    save_state(output_dir, state)
    return {
        "scenario_id": scenario,
        "status": state["status"],
        "completed_trials": len(completed),
        "new_trials": new_trials,
        "target_trials": target_count,
        "reference_stable": bool(scenario_state["reference_stable"]),
        "project_ci_stable": bool(scenario_state["project_ci_stable"]),
    }


def parse_scenario_code(code: str) -> tuple[float, int]:
    try:
        if not (code.startswith("C") and "_G" in code):
            raise ValueError
        cpart, gpart = code[1:].split("_G", 1)
        collection_probability = int(cpart) / 100.0
        recovery_rate_pct = int(gpart)
    except Exception as exc:
        raise ValueError("scenario must look like C030_G000") from exc
    if collection_probability not in COLLECTION_PROBABILITIES:
        raise ValueError("scenario collection level is not in the 5-level matrix")
    if recovery_rate_pct not in GUARANTEE_RECOVERY_RATES:
        raise ValueError("scenario recovery level is not in the 5-level matrix")
    return collection_probability, recovery_rate_pct


def build_arg_parser():
    import argparse

    parser = argparse.ArgumentParser(description="Stage 8 adaptive batch runner")
    parser.add_argument("--scenario", help="single matrix scenario, e.g. C100_G100")
    parser.add_argument("--output", default="results_stage8", help="batch output directory")
    parser.add_argument("--demo-total", type=int, help="explicit small test count; never used by production defaults")
    parser.add_argument("--stop-after-new-trials", type=int, help="intentionally stop after this many newly completed trials")
    parser.add_argument("--keep-daily", action="store_true")
    parser.add_argument("--include-raw-logs", action="store_true")
    return parser


def main() -> int:
    parser = build_arg_parser()
    args = parser.parse_args()
    output_dir = Path(args.output)
    if args.demo_total is not None and args.demo_total < 1:
        parser.error("--demo-total must be >= 1")
    if args.stop_after_new_trials is not None and args.stop_after_new_trials < 1:
        parser.error("--stop-after-new-trials must be >= 1")

    if args.scenario:
        pairs = [parse_scenario_code(args.scenario)]
    else:
        if args.demo_total is not None or args.stop_after_new_trials is not None:
            parser.error("--scenario is required for an explicit small/stop test run")
        pairs = [(p, g) for p in COLLECTION_PROBABILITIES for g in GUARANTEE_RECOVERY_RATES]

    results = []
    for collection_probability, recovery_rate_pct in pairs:
        results.append(run_scenario_batch(
            collection_probability,
            recovery_rate_pct,
            output_dir,
            demo_total=args.demo_total,
            stop_after_new_trials=args.stop_after_new_trials,
            keep_daily=args.keep_daily,
            include_raw_logs=args.include_raw_logs,
        ))
        # An intentional stop is a test event; do not start the next scenario.
        if results[-1]["status"] == "intentionally_stopped":
            break

    print(json.dumps({"stage": 8, "results": results}, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
