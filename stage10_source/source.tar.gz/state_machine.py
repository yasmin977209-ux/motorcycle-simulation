"""Chapter 4 — exclusive bike states and transition table."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date
from enum import Enum
from typing import Optional

from constants import (
    EXPANSION_CUTOFF_DATE,
    GRACE_PRIMARY_UPPER,
    NOTICE_PRIMARY_UPPER,
    PRIMARY_DEFAULT_AMOUNT,
    SECONDARY_DEFAULT_AMOUNT,
    WAITING_PRIMARY_UPPER,
)
from dateutils import is_business_day


class BikeState(str, Enum):
    PREP = "PREP"
    ACTIVE_PRIMARY = "ACTIVE_PRIMARY"
    WAITING_PRIMARY = "WAITING_PRIMARY"
    NOTICE_PRIMARY = "NOTICE_PRIMARY"
    GRACE_PRIMARY = "GRACE_PRIMARY"
    POST_MATURITY_SETTLEMENT = "POST_MATURITY_SETTLEMENT"
    AVAILABLE_FOR_SECONDARY = "AVAILABLE_FOR_SECONDARY"
    ACTIVE_SECONDARY = "ACTIVE_SECONDARY"
    NOTICE_SECONDARY = "NOTICE_SECONDARY"
    OWNED_TRANSFERRED = "OWNED_TRANSFERRED"
    HELD_AS_ASSET = "HELD_AS_ASSET"


EXCLUSIVE_BIKE_STATES = tuple(state.value for state in BikeState)

# Chapter 4.3 — reference transition table, represented as immutable records.
@dataclass(frozen=True)
class TransitionRule:
    from_state: str
    to_state: str
    condition: str
    stage: str


TRANSITION_TABLE = (
    TransitionRule("PREP", "ACTIVE_PRIMARY", "prep_paid and customs_paid and first business day on/after actual_ready_date", "M3"),
    TransitionRule("ACTIVE_PRIMARY", "WAITING_PRIMARY", "0 < outstanding < 31,500", "M10"),
    TransitionRule("WAITING_PRIMARY", "ACTIVE_PRIMARY", "outstanding == 0", "M10"),
    TransitionRule("WAITING_PRIMARY", "NOTICE_PRIMARY", "31,500 <= outstanding < 42,000", "M10"),
    TransitionRule("NOTICE_PRIMARY", "WAITING_PRIMARY|ACTIVE_PRIMARY", "according to new outstanding after payment", "M10"),
    TransitionRule("NOTICE_PRIMARY", "GRACE_PRIMARY", "42,000 <= outstanding < 45,000", "M10"),
    TransitionRule("GRACE_PRIMARY", "lower primary state", "according to new outstanding after payment", "M10"),
    TransitionRule("GRACE_PRIMARY", "AVAILABLE_FOR_SECONDARY", "outstanding >= 45,000", "M11"),
    TransitionRule("ACTIVE_PRIMARY|WAITING_PRIMARY|NOTICE_PRIMARY|GRACE_PRIMARY", "OWNED_TRANSFERRED", "current_date == maturity_date and total_due == total_paid", "M12"),
    TransitionRule("ACTIVE_PRIMARY|WAITING_PRIMARY|NOTICE_PRIMARY|GRACE_PRIMARY", "POST_MATURITY_SETTLEMENT", "current_date == maturity_date and total_due > total_paid", "M12"),
    TransitionRule("POST_MATURITY_SETTLEMENT", "OWNED_TRANSFERRED", "settlement_legacy_debt_remaining == 0", "M13"),
    TransitionRule("POST_MATURITY_SETTLEMENT", "AVAILABLE_FOR_SECONDARY", "30 business days elapsed without full settlement", "M13"),
    TransitionRule("AVAILABLE_FOR_SECONDARY", "ACTIVE_SECONDARY", "first eligible business day", "M3"),
    TransitionRule("ACTIVE_SECONDARY", "NOTICE_SECONDARY", "0 < outstanding < 10,000", "M10"),
    TransitionRule("NOTICE_SECONDARY", "ACTIVE_SECONDARY", "outstanding == 0", "M10"),
    TransitionRule("NOTICE_SECONDARY", "AVAILABLE_FOR_SECONDARY", "outstanding >= 10,000", "M11"),
    TransitionRule("ACTIVE_SECONDARY|NOTICE_SECONDARY", "HELD_AS_ASSET", "dynamic closure conditions", "M15"),
    TransitionRule("any active state except OWNED_TRANSFERRED", "HELD_AS_ASSET", "dynamic closure conditions", "M15"),
)


def derive_state_from_balance(
    outstanding_amount: int,
    daily_rate: int,
    contract_type: str,
) -> Optional[str]:
    """Chapter 4.2 — memoryless derivation from current outstanding only.

    Returning None at the termination threshold is intentional: termination is
    performed in M11, not inside this classifier.
    """
    if contract_type == "PRIMARY":
        if outstanding_amount == 0:
            return BikeState.ACTIVE_PRIMARY.value
        if outstanding_amount < WAITING_PRIMARY_UPPER:
            return BikeState.WAITING_PRIMARY.value
        if outstanding_amount < NOTICE_PRIMARY_UPPER:
            return BikeState.NOTICE_PRIMARY.value
        if outstanding_amount < GRACE_PRIMARY_UPPER:
            return BikeState.GRACE_PRIMARY.value
        return None

    if contract_type == "SECONDARY":
        if outstanding_amount == 0:
            return BikeState.ACTIVE_SECONDARY.value
        if outstanding_amount < SECONDARY_DEFAULT_AMOUNT:
            return BikeState.NOTICE_SECONDARY.value
        return None

    raise ValueError(f"Unsupported contract_type: {contract_type}")


def start_contract_from_prep(
    current_state: str,
    *,
    prep_paid: bool,
    customs_paid: bool,
    actual_ready_date: date,
    current_date: date,
    contract_type: str,
) -> str:
    """M3 transition for PREP or AVAILABLE_FOR_SECONDARY."""
    if not (prep_paid and customs_paid):
        return current_state
    if not is_business_day(current_date):
        return current_state
    if current_date < actual_ready_date:
        return current_state
    if current_state == BikeState.PREP.value and contract_type == "PRIMARY":
        return BikeState.ACTIVE_PRIMARY.value
    if (
        current_state == BikeState.AVAILABLE_FOR_SECONDARY.value
        and contract_type == "SECONDARY"
    ):
        return BikeState.ACTIVE_SECONDARY.value
    return current_state


def classify_daily_balance(current_state: str, outstanding_amount: int, daily_rate: int, contract_type: str) -> str:
    """M10 classification; threshold crossing itself remains for M11."""
    derived = derive_state_from_balance(outstanding_amount, daily_rate, contract_type)
    return current_state if derived is None else derived


def terminate_for_default(current_state: str, outstanding_amount: int, contract_type: str) -> str:
    """M11 termination transition once the threshold has been crossed."""
    if contract_type == "PRIMARY" and outstanding_amount >= PRIMARY_DEFAULT_AMOUNT:
        if current_state in {
            BikeState.ACTIVE_PRIMARY.value,
            BikeState.WAITING_PRIMARY.value,
            BikeState.NOTICE_PRIMARY.value,
            BikeState.GRACE_PRIMARY.value,
        }:
            return BikeState.AVAILABLE_FOR_SECONDARY.value
    elif contract_type == "SECONDARY" and outstanding_amount >= SECONDARY_DEFAULT_AMOUNT:
        if current_state in {
            BikeState.ACTIVE_SECONDARY.value,
            BikeState.NOTICE_SECONDARY.value,
        }:
            return BikeState.AVAILABLE_FOR_SECONDARY.value
    return current_state


def resolve_primary_maturity(
    current_state: str,
    *,
    current_date: date,
    maturity_date: date,
    total_due: int,
    total_paid: int,
) -> str:
    """M12: resolve maturity only on the exact maturity date, after day accrual/collection."""
    primary_states = {
        BikeState.ACTIVE_PRIMARY.value,
        BikeState.WAITING_PRIMARY.value,
        BikeState.NOTICE_PRIMARY.value,
        BikeState.GRACE_PRIMARY.value,
    }
    if current_state not in primary_states or current_date != maturity_date:
        return current_state
    if total_paid == total_due:
        return BikeState.OWNED_TRANSFERRED.value
    if total_paid < total_due:
        return BikeState.POST_MATURITY_SETTLEMENT.value
    raise ValueError("total_paid cannot exceed total_due")


def resolve_settlement(
    current_state: str,
    *,
    legacy_debt_remaining: int,
    settlement_failed: bool,
) -> str:
    """M13 terminal settlement outcomes for the current day."""
    if current_state != BikeState.POST_MATURITY_SETTLEMENT.value:
        return current_state
    if legacy_debt_remaining < 0:
        raise ValueError("legacy_debt_remaining cannot be negative")
    if legacy_debt_remaining == 0:
        return BikeState.OWNED_TRANSFERRED.value
    if settlement_failed:
        return BikeState.AVAILABLE_FOR_SECONDARY.value
    return current_state


def apply_dynamic_closure(current_state: str, *, closure_conditions_met: bool) -> str:
    """M15 state target; final day processing itself belongs to daily_engine."""
    if not closure_conditions_met:
        return current_state
    if current_state == BikeState.OWNED_TRANSFERRED.value:
        return current_state
    # PREP/AVAILABLE are not "active" in the narrow state-table prose, but
    # Chapter 13.4's closure procedure states remaining non-owned/non-held bikes
    # become HELD_AS_ASSET. The caller decides whether closure has been reached.
    return BikeState.HELD_AS_ASSET.value


def next_business_day_on_or_after_ready(actual_ready_date: date) -> date:
    """Utility for the M3 readiness condition, kept local to state semantics."""
    cursor = actual_ready_date
    while not is_business_day(cursor):
        # Friday-only non-business calendar is enforced by dateutils.
        from datetime import timedelta

        cursor += timedelta(days=1)
    return cursor


def validate_transition_table() -> None:
    """Structural guard: exactly the 11 exclusive states and no cancelled states."""
    required = {
        "PREP",
        "ACTIVE_PRIMARY",
        "WAITING_PRIMARY",
        "NOTICE_PRIMARY",
        "GRACE_PRIMARY",
        "POST_MATURITY_SETTLEMENT",
        "AVAILABLE_FOR_SECONDARY",
        "ACTIVE_SECONDARY",
        "NOTICE_SECONDARY",
        "OWNED_TRANSFERRED",
        "HELD_AS_ASSET",
    }
    assert set(EXCLUSIVE_BIKE_STATES) == required
    forbidden = {"TERMINATION_PENDING", "MINI_PREP", "PENDING_RECALL", "GUARANTEE_PENDING"}
    assert not (set(EXCLUSIVE_BIKE_STATES) & forbidden)
    assert EXPANSION_CUTOFF_DATE is not None
