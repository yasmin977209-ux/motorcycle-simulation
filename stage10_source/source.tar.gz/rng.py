import hashlib

from constants import MASTER_SEED


def derive_seed(master_seed, scenario_id, trial_id, bike_id, date, event_type):
    key = f"{master_seed}|{scenario_id}|{trial_id}|{bike_id}|{date}|{event_type}"
    return hashlib.sha256(key.encode()).digest()


def rng_draw(seed_bytes):
    value = int.from_bytes(seed_bytes[:8], "big") / 2**64
    return value


def scenario_id(collection_probability, recovery_rate_pct):
    return f"C{collection_probability * 100:03.0f}_G{recovery_rate_pct:03d}"
