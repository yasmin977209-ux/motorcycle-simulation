"""Chapter 12 — canonical daily engine M1–M17.

Stage 3b implementation only. No statistical/Excel layer is included here.
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import date, timedelta

from constants import (
    BIKE_BASE_PURCHASE_COST, CUSTOMS_AND_REGISTRATION_COST, EXPANSION_CUTOFF_DATE,
    FULL_PREP_CASH_REQUIREMENT, PRIMARY_DAILY_RENT, SECONDARY_DAILY_RENT,
    SETTLEMENT_DAILY_RENT, FRIDAY_FEE, OIL_SERVICE_COST, DEPRECIATION_RATE_PER_DAY,
    MASTER_SEED,
)
from dateutils import is_business_day, scheduled_ready_date, primary_maturity_date, delivery_date
from entities import Bike, Contract, Tenant, Guarantor, ReceivableEntry, Project
from state_machine import derive_state_from_balance, terminate_for_default, resolve_primary_maturity
from friday import apply_friday_fee_and_oil, eligible_friday_number
from collection import apply_ordinary_collection
from settlement import apply_legacy_debt_collection, settlement_status
from depreciation import apply_daily_depreciation, apply_ownership_writeoff
from guarantee import create_guarantee_claim, can_settle_claim, settle_guarantee_claim
from accounting import (
    initialize_accounting, accrue_rent, collect_from_ar, record_settlement_rent,
    record_friday_fee, record_oil_service, record_prep_expense, record_purchase,
    record_customs_registration, record_depreciation, transfer_ar_to_guarantee,
    settle_guarantee_accounting, record_asset_writeoff, finalize_daily_accounting,
)
from partner_equity import record_eligible_inflow, spend_from_partner1_memo
from closure import execute_dynamic_closure
from rng import derive_seed, rng_draw


M_STAGE_ORDER = tuple(f"M{i}" for i in range(1, 18))
PRIMARY_STATES = {"ACTIVE_PRIMARY", "WAITING_PRIMARY", "NOTICE_PRIMARY", "GRACE_PRIMARY"}
SECONDARY_STATES = {"ACTIVE_SECONDARY", "NOTICE_SECONDARY"}
POSSESSION_STATES = PRIMARY_STATES | SECONDARY_STATES | {"POST_MATURITY_SETTLEMENT"}


@dataclass(frozen=True)
class DailyRunResult:
    current_date: date
    simulation_stopped: bool
    balance_difference: int


def _contract(project: Project, bike: Bike) -> Contract:
    if bike.current_contract_id is None:
        raise ValueError(f"bike {bike.bike_id} has no current contract")
    found = next((c for c in project.contracts if c.contract_id == bike.current_contract_id), None)
    if found is None:
        raise ValueError(f"missing contract {bike.current_contract_id}")
    return found


def _tenant(project: Project, tenant_id: str | None) -> Tenant | None:
    if tenant_id is None:
        return None
    return next((t for t in project.tenants if t.tenant_id == tenant_id), None)


def _new_id(prefix: str, collection) -> str:
    return f"{prefix}{len(collection) + 1:06d}"


def _event(project: Project, *, current_date, bike: Bike, event_type: str, previous_state=None,
           new_state=None, contract_id=None, amount=None, before=None, after=None, reason="", notes=""):
    project.event_log.append(project.make_event(
        event_id=_new_id("EV", project.event_log), event_date=current_date, bike=bike,
        event_type=event_type, previous_state=previous_state, new_state=new_state,
        contract_id=contract_id, tenant_id=bike.current_tenant_id,
        amount=amount, before=before, after=after, reason=reason, notes=notes,
    ))


def _claim(project: Project, bike: Bike, contract: Contract, source: str, amount: int, current_date: date):
    claim = create_guarantee_claim(
        claim_id=_new_id("CL", project.guarantee_claims),
        bike_id=bike.bike_id,
        contract_id=contract.contract_id,
        tenant_id=contract.tenant_id,
        guarantor_id=contract.guarantor_id,
        claim_source=source,
        claim_amount=amount,
        created_date=current_date,
        recovery_rate_pct=project.recovery_rate_pct,
    )
    project.guarantee_claims.append(claim)
    _event(project, current_date=current_date, bike=bike, event_type="GUARANTEE_CLAIM_CREATED",
           contract_id=contract.contract_id, amount=amount, before=amount, after=amount,
           reason=source)
    return claim


def _receivable(project: Project, bike: Bike, contract: Contract, amount: int, current_date: date):
    rec = ReceivableEntry(
        receivable_id=_new_id("RC", project.receivables),
        bike_id=bike.bike_id, contract_id=contract.contract_id, tenant_id=contract.tenant_id,
        source="SETTLEMENT_LEGACY_DEBT", original_amount=amount, collected_amount=0,
        remaining_amount=amount, status="OUTSTANDING", created_date=current_date,
    )
    project.receivables.append(rec)
    bike.receivables_ledger.append(rec)
    return rec


def create_initial_project(recovery_rate_pct: int = 100) -> Project:
    project = Project()
    project.recovery_rate_pct = recovery_rate_pct
    project.simulation_stopped = False
    project.final_close_date = None
    project.final_net_project_equity = None
    project.partner1_final_entitlement = None
    project.partner2_final_entitlement = None
    initialize_accounting(project)
    for i in range(1, 11):
        bike = Bike(
            bike_id=f"BK{i:06d}", source="INITIAL",
            purchase_date=date(2026, 12, 26), scheduled_ready_date=date(2027, 1, 1),
            funding_completion_date=date(2026, 12, 26), actual_ready_date=date(2027, 1, 1),
            prep_paid=True, customs_paid=True, gross_cost=360_000,
        )
        project.bikes.append(bike)
    return project


def _create_expansion_bike(project: Project, current_date: date) -> Bike:
    bike = Bike(
        bike_id=_new_id("BK", project.bikes), source="EXPANSION",
        purchase_date=current_date,
        scheduled_ready_date=scheduled_ready_date(current_date),
        prep_paid=False, customs_paid=False, gross_cost=BIKE_BASE_PURCHASE_COST,
    )
    project.bikes.append(bike)
    return bike


def _create_contract(project: Project, bike: Bike, contract_type: str, current_date: date) -> Contract:
    tenant_type = "ORIGINAL" if contract_type == "PRIMARY" else "SECONDARY"
    daily_rate = PRIMARY_DAILY_RENT if contract_type == "PRIMARY" else SECONDARY_DAILY_RENT
    tenant_id = _new_id("TN", project.tenants)
    guarantor_id = _new_id("GR", project.guarantors)
    contract_id = _new_id("CT", project.contracts)
    tenant = Tenant(
        tenant_id=tenant_id, tenant_type=tenant_type,
        contract_id=contract_id, guarantor_id=guarantor_id, start_date=current_date,
    )
    guarantor = Guarantor(guarantor_id=guarantor_id, related_contract_id=contract_id, related_tenant_id=tenant_id)
    contract = Contract(
        contract_id=contract_id, bike_id=bike.bike_id, tenant_id=tenant_id, guarantor_id=guarantor_id,
        contract_type=contract_type, daily_rate=daily_rate, start_date=current_date,
        maturity_date=primary_maturity_date(current_date) if contract_type == "PRIMARY" else None,
    )
    project.tenants.append(tenant)
    project.guarantors.append(guarantor)
    project.contracts.append(contract)
    return contract


def _m1(day: date) -> tuple[bool, bool]:
    return day.weekday() == 4, is_business_day(day)


def _m2(project: Project, current_date: date, is_business_day_today: bool):
    if not is_business_day_today:
        return
    prep_bikes = sorted((b for b in project.bikes if b.current_state == "PREP"), key=lambda b: (b.purchase_date, b.bike_id))
    for bike in prep_bikes:
        if not bike.prep_paid and project.project_cash >= 4_000 and project.partner1_reinvestment_balance >= 4_000:
            spend_from_partner1_memo(project, 4_000)
            record_prep_expense(project, 4_000)
            bike.prep_paid = True
            _event(project, current_date=current_date, bike=bike, event_type="PREP_COMPLETED", amount=4_000, reason="prep paid")
        if not bike.customs_paid and project.project_cash >= CUSTOMS_AND_REGISTRATION_COST and project.partner1_reinvestment_balance >= CUSTOMS_AND_REGISTRATION_COST:
            spend_from_partner1_memo(project, CUSTOMS_AND_REGISTRATION_COST)
            record_customs_registration(project, CUSTOMS_AND_REGISTRATION_COST)
            bike.customs_paid = True
            bike.gross_cost += CUSTOMS_AND_REGISTRATION_COST
            _event(project, current_date=current_date, bike=bike, event_type="PREP_COMPLETED", amount=CUSTOMS_AND_REGISTRATION_COST, reason="customs and registration paid")
        if bike.prep_paid and bike.customs_paid and bike.actual_ready_date is None:
            bike.funding_completion_date = current_date
            bike.actual_ready_date = max(bike.scheduled_ready_date, bike.funding_completion_date)

    if current_date <= EXPANSION_CUTOFF_DATE and not any(
        (b.current_state == "PREP" and (not b.prep_paid or not b.customs_paid)) for b in project.bikes
    ):
        while project.project_cash >= BIKE_BASE_PURCHASE_COST and project.partner1_reinvestment_balance >= BIKE_BASE_PURCHASE_COST:
            spend_from_partner1_memo(project, BIKE_BASE_PURCHASE_COST)
            record_purchase(project, BIKE_BASE_PURCHASE_COST)
            bike = _create_expansion_bike(project, current_date)
            _event(project, current_date=current_date, bike=bike, event_type="BIKE_PURCHASED", previous_state=None, new_state="PREP", amount=BIKE_BASE_PURCHASE_COST, reason="expansion purchase")
            _event(project, current_date=current_date, bike=bike, event_type="EXPANSION_PURCHASE", amount=BIKE_BASE_PURCHASE_COST, reason="eligible expansion purchase")


def _m3(project: Project, current_date: date, is_business_day_today: bool):
    if not is_business_day_today:
        return
    for bike in list(project.bikes):
        if bike.current_state == "PREP" and bike.actual_ready_date is not None and current_date >= bike.actual_ready_date:
            contract = _create_contract(project, bike, "PRIMARY", current_date)
            bike.delivery_date = current_date
            bike.current_contract_id = contract.contract_id
            bike.current_tenant_id = contract.tenant_id
            bike.current_state = "ACTIVE_PRIMARY"
            bike.lifecycle_cycle_number = 1
            _event(project, current_date=current_date, bike=bike, event_type="PRIMARY_CONTRACT_STARTED",
                   previous_state="PREP", new_state="ACTIVE_PRIMARY", contract_id=contract.contract_id,
                   reason="first business day on/after actual_ready_date")
        elif bike.current_state == "AVAILABLE_FOR_SECONDARY":
            contract = _create_contract(project, bike, "SECONDARY", current_date)
            bike.current_contract_id = contract.contract_id
            bike.current_tenant_id = contract.tenant_id
            bike.secondary_cycle_count += 1
            bike.lifecycle_cycle_number += 1
            bike.current_state = "ACTIVE_SECONDARY"
            _event(project, current_date=current_date, bike=bike, event_type="SECONDARY_CONTRACT_STARTED",
                   previous_state="AVAILABLE_FOR_SECONDARY", new_state="ACTIVE_SECONDARY", contract_id=contract.contract_id,
                   reason="first eligible business day")


def _m4(project: Project) -> dict[str, bool]:
    return {bike.bike_id: bike.current_state in POSSESSION_STATES for bike in project.bikes}


def _m5(project: Project, current_date: date, is_business_day_today: bool):
    if is_business_day_today:
        for bike in list(project.bikes):
            if bike.current_state in PRIMARY_STATES:
                contract = _contract(project, bike)
                contract.total_due += PRIMARY_DAILY_RENT
                accrue_rent(project, contract_type="PRIMARY", amount=PRIMARY_DAILY_RENT)
            elif bike.current_state in SECONDARY_STATES:
                contract = _contract(project, bike)
                contract.total_due += SECONDARY_DAILY_RENT
                accrue_rent(project, contract_type="SECONDARY", amount=SECONDARY_DAILY_RENT)
            elif bike.current_state == "POST_MATURITY_SETTLEMENT":
                bike.settlement_rent_due_total += SETTLEMENT_DAILY_RENT
                bike.settlement_rent_collected_total += SETTLEMENT_DAILY_RENT
                record_settlement_rent(project, SETTLEMENT_DAILY_RENT)
                record_eligible_inflow(project, SETTLEMENT_DAILY_RENT)


def _m6(project: Project, current_date: date, possession_today: dict[str, bool]):
    if current_date.weekday() != 4:
        return
    for bike in list(project.bikes):
        if possession_today.get(bike.bike_id, False):
            contract = _contract(project, bike)
            start = bike.delivery_date if contract.contract_type == "PRIMARY" else contract.start_date
            # Use isolated function as the event calculator; its counter mutation is then mirrored in accounting.
            result = apply_friday_fee_and_oil(contract, start, current_date, was_in_possession=True)
            if result.eligible:
                record_friday_fee(project, result.friday_fee)
                record_eligible_inflow(project, result.friday_fee)
                _event(project, current_date=current_date, bike=bike, event_type="FRIDAY_FEE_COLLECTED",
                       contract_id=contract.contract_id, amount=result.friday_fee, reason="eligible Friday fee")
                if result.oil_service_expense:
                    record_oil_service(project, result.oil_service_expense)
                    _event(project, current_date=current_date, bike=bike, event_type="OIL_SERVICE_PERFORMED",
                           contract_id=contract.contract_id, amount=result.oil_service_expense, reason="even eligible Friday")


def _m7(project: Project, possession_today: dict[str, bool], current_date: date):
    for bike in list(project.bikes):
        if possession_today.get(bike.bike_id, False):
            result = apply_daily_depreciation(bike, was_in_possession=True)
            if result.applied:
                record_depreciation(project, result.depreciation_amount)
                _event(project, current_date=current_date, bike=bike, event_type="DEPRECIATION_RECORDED",
                       amount=result.depreciation_amount, reason="daily actual possession")


def _m8(project: Project, current_date: date, probability: float, scenario_id: str, trial_id: int):
    for bike in list(project.bikes):
        if bike.current_state in PRIMARY_STATES | SECONDARY_STATES:
            contract = _contract(project, bike)
            event_type = "PRIMARY_COLLECTION" if contract.contract_type == "PRIMARY" else "SECONDARY_COLLECTION"
            result = apply_ordinary_collection(
                contract, probability=probability, master_seed=MASTER_SEED,
                scenario_id=scenario_id, trial_id=trial_id, bike_id=bike.bike_id,
                current_date=current_date, event_type=event_type,
            )
            if result.collected:
                collect_from_ar(project, result.collected)
                record_eligible_inflow(project, result.collected)
        elif bike.current_state == "POST_MATURITY_SETTLEMENT" and bike.settlement_legacy_debt_remaining:
            rec = next((r for r in project.receivables if r.receivable_id in {x.receivable_id for x in bike.receivables_ledger} and r.status == "OUTSTANDING"), None)
            if rec is None:
                continue
            result = apply_legacy_debt_collection(
                bike, rec, probability=probability, master_seed=MASTER_SEED,
                scenario_id=scenario_id, trial_id=trial_id, bike_id=bike.bike_id, current_date=current_date,
            )
            if result.payment:
                collect_from_ar(project, result.payment)
                record_eligible_inflow(project, result.payment)


def _m9(project: Project):
    for bike in list(project.bikes):
        if bike.current_state in PRIMARY_STATES:
            contract = _contract(project, bike)
            new_state = derive_state_from_balance(contract.total_due - contract.total_paid, PRIMARY_DAILY_RENT, "PRIMARY")
            if new_state is not None:
                bike.current_state = new_state
        elif bike.current_state in SECONDARY_STATES:
            contract = _contract(project, bike)
            new_state = derive_state_from_balance(contract.total_due - contract.total_paid, SECONDARY_DAILY_RENT, "SECONDARY")
            if new_state is not None:
                bike.current_state = new_state


def _m10():
    return None


def _m11(project: Project, current_date: date):
    for bike in list(project.bikes):
        if bike.current_state in PRIMARY_STATES | SECONDARY_STATES:
            contract = _contract(project, bike)
            outstanding = contract.total_due - contract.total_paid
            if contract.contract_type == "PRIMARY" and outstanding >= 45_000:
                claim = _claim(project, bike, contract, "PRIMARY_EARLY_TERMINATION", outstanding, current_date)
                transfer_ar_to_guarantee(project, outstanding)
                contract.status = "TERMINATED"
                tenant = _tenant(project, contract.tenant_id)
                if tenant:
                    tenant.end_date = current_date
                before = outstanding
                bike.current_contract_id = None
                bike.current_tenant_id = None
                previous = bike.current_state
                bike.current_state = "AVAILABLE_FOR_SECONDARY"
                bike.termination_count += 1
                _event(project, current_date=current_date, bike=bike, event_type="PRIMARY_TERMINATED",
                       previous_state=previous, new_state="AVAILABLE_FOR_SECONDARY", contract_id=contract.contract_id,
                       amount=outstanding, before=before, after=0, reason="primary default threshold")
            elif contract.contract_type == "SECONDARY" and outstanding >= 10_000:
                claim = _claim(project, bike, contract, "SECONDARY_EARLY_TERMINATION", outstanding, current_date)
                transfer_ar_to_guarantee(project, outstanding)
                contract.status = "TERMINATED"
                tenant = _tenant(project, contract.tenant_id)
                if tenant:
                    tenant.end_date = current_date
                previous = bike.current_state
                bike.current_contract_id = None
                bike.current_tenant_id = None
                bike.current_state = "AVAILABLE_FOR_SECONDARY"
                bike.termination_count += 1
                _event(project, current_date=current_date, bike=bike, event_type="SECONDARY_TERMINATED",
                       previous_state=previous, new_state="AVAILABLE_FOR_SECONDARY", contract_id=contract.contract_id,
                       amount=outstanding, before=outstanding, after=0, reason="secondary default threshold")


def _m12(project: Project, current_date: date):
    for bike in list(project.bikes):
        if bike.current_state not in PRIMARY_STATES:
            continue
        contract = _contract(project, bike)
        if contract.status == "ACTIVE" and contract.maturity_date == current_date:
            outstanding = contract.total_due - contract.total_paid
            previous = bike.current_state
            if outstanding == 0:
                bike.current_state = "OWNED_TRANSFERRED"
                contract.status = "SETTLED"
                tenant = _tenant(project, contract.tenant_id)
                if tenant:
                    tenant.end_date = current_date
                bike.current_contract_id = None
                bike.current_tenant_id = None
                bike._pending_writeoff_today = True
                _event(project, current_date=current_date, bike=bike, event_type="PRIMARY_CONTRACT_MATURED",
                       previous_state=previous, new_state="OWNED_TRANSFERRED", contract_id=contract.contract_id,
                       reason="maturity with full payment")
                _event(project, current_date=current_date, bike=bike, event_type="OWNERSHIP_TRANSFERRED",
                       previous_state=previous, new_state="OWNED_TRANSFERRED", contract_id=contract.contract_id,
                       reason="maturity with full payment")
            else:
                bike.current_state = "POST_MATURITY_SETTLEMENT"
                contract.status = "MATURED"
                bike.settlement_legacy_debt_original = outstanding
                bike.settlement_legacy_debt_remaining = outstanding
                bike.settlement_business_days_elapsed = 0
                bike.settlement_start_date = None
                _receivable(project, bike, contract, outstanding, current_date)
                _event(project, current_date=current_date, bike=bike, event_type="PRIMARY_CONTRACT_MATURED",
                       previous_state=previous, new_state="POST_MATURITY_SETTLEMENT", contract_id=contract.contract_id,
                       amount=outstanding, before=contract.total_due, after=contract.total_paid, reason="maturity with debt")
                _event(project, current_date=current_date, bike=bike, event_type="SETTLEMENT_STARTED",
                       previous_state=previous, new_state="POST_MATURITY_SETTLEMENT", contract_id=contract.contract_id,
                       amount=outstanding, reason="settlement state entered; first settlement workday is next workday")


def _m13(project: Project, current_date: date, is_business_day_today: bool):
    if not is_business_day_today:
        return
    for bike in list(project.bikes):
        if bike.current_state != "POST_MATURITY_SETTLEMENT":
            continue
        if bike.settlement_start_date is None:
            # A newly entered settlement cannot be counted here on its entry day.
            maturity = next((c.maturity_date for c in project.contracts if c.contract_id == bike.current_contract_id), None)
            if maturity is None:
                maturity = current_date - timedelta(days=1)
            if current_date > maturity:
                bike.settlement_start_date = current_date
                bike.settlement_business_days_elapsed = 1
            continue
        bike.settlement_business_days_elapsed += 1
        if bike.settlement_legacy_debt_remaining == 0:
            contract = _contract(project, bike)
            contract.status = "SETTLED"
            previous = bike.current_state
            bike.current_state = "OWNED_TRANSFERRED"
            bike._pending_writeoff_today = True
            tenant = _tenant(project, contract.tenant_id)
            if tenant:
                tenant.end_date = current_date
            bike.current_contract_id = None
            bike.current_tenant_id = None
            _event(project, current_date=current_date, bike=bike, event_type="SETTLEMENT_COMPLETED",
                   previous_state=previous, new_state="OWNED_TRANSFERRED", reason="legacy debt fully repaid")
            _event(project, current_date=current_date, bike=bike, event_type="OWNERSHIP_TRANSFERRED",
                   previous_state=previous, new_state="OWNED_TRANSFERRED", reason="settlement success")
        elif bike.settlement_business_days_elapsed > 30:
            contract = _contract(project, bike)
            remaining = bike.settlement_legacy_debt_remaining
            claim = _claim(project, bike, contract, "POST_MATURITY_SETTLEMENT_FAILURE", remaining, current_date)
            transfer_ar_to_guarantee(project, remaining)
            rec = next((r for r in project.receivables if r.bike_id == bike.bike_id and r.status == "OUTSTANDING"), None)
            if rec:
                rec.status = "TRANSFERRED_TO_GUARANTEE"
                rec.remaining_amount = 0
            bike.settlement_legacy_debt_remaining = 0
            contract.status = "TERMINATED"
            previous = bike.current_state
            bike.current_contract_id = None
            bike.current_tenant_id = None
            bike.current_state = "AVAILABLE_FOR_SECONDARY"
            _event(project, current_date=current_date, bike=bike, event_type="SETTLEMENT_FAILED",
                   previous_state=previous, new_state="AVAILABLE_FOR_SECONDARY", amount=remaining,
                   reason="settlement exceeded 30 business days")


def _m14(project: Project, current_date: date):
    for claim in list(project.guarantee_claims):
        if can_settle_claim(claim, current_date):
            result = settle_guarantee_claim(claim, settlement_date=current_date)
            settle_guarantee_accounting(project, claim.claim_amount, result.recovered_amount, result.bad_debt_amount)
            record_eligible_inflow(project, result.recovered_amount)
            bike = next((b for b in project.bikes if b.bike_id == claim.bike_id), None)
            if bike is not None:
                _event(project, current_date=current_date, bike=bike,
                       event_type="GUARANTEE_RECOVERED" if result.recovered_amount > 0 else "GUARANTEE_WRITTEN_OFF",
                       contract_id=claim.contract_id, amount=claim.claim_amount,
                       before=claim.claim_amount, after=0, reason=claim.claim_source)


def _m15(project: Project, current_date: date):
    result = execute_dynamic_closure(project, current_date)
    return result.closed


def _m16(project: Project, current_date: date):
    for bike in list(project.bikes):
        if getattr(bike, "_pending_writeoff_today", False):
            old_accumulated = bike.accumulated_depreciation
            result = apply_ownership_writeoff(bike)
            record_asset_writeoff(project, bike.gross_cost, old_accumulated)
            bike._pending_writeoff_today = False


def _m17(project: Project, current_date: date):
    return finalize_daily_accounting(project, current_date=current_date, stage_order=M_STAGE_ORDER)


def run_day(project: Project, current_date: date, *, collection_probability: float, scenario_id: str, trial_id: int) -> DailyRunResult:
    # M1
    is_friday_today, is_business_day_today = _m1(current_date)
    # M2
    _m2(project, current_date, is_business_day_today)
    # M3
    _m3(project, current_date, is_business_day_today)
    # M4
    possession_today = _m4(project)
    # M5
    _m5(project, current_date, is_business_day_today)
    # M6
    _m6(project, current_date, possession_today)
    # M7
    _m7(project, possession_today, current_date)
    # M8
    _m8(project, current_date, collection_probability, scenario_id, trial_id)
    # M9
    _m9(project)
    # M10
    _m10()
    # M11
    _m11(project, current_date)
    # M12
    _m12(project, current_date)
    # M13
    _m13(project, current_date, is_business_day_today)
    # M14
    _m14(project, current_date)
    # M15
    closed = _m15(project, current_date)
    # M16
    _m16(project, current_date)
    # M17
    snap = _m17(project, current_date)
    return DailyRunResult(current_date, closed, snap.balance_difference)


def run_deterministic_trial(*, recovery_rate_pct: int = 100, trial_id: int = 1, scenario_id: str = "C100_G100"):
    project = create_initial_project(recovery_rate_pct=recovery_rate_pct)
    current_date = date(2027, 1, 1)
    while True:
        run_day(project, current_date, collection_probability=1.0, scenario_id=scenario_id, trial_id=trial_id)
        if project.simulation_stopped:
            break
        current_date += timedelta(days=1)
    return project
