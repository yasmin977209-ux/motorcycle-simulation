"""Chapter 6 — isolated ordinary collection functions."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from constants import PRIMARY_DAILY_RENT, SECONDARY_DAILY_RENT
from dateutils import is_business_day
from entities import Contract
from rng import derive_seed, rng_draw


@dataclass(frozen=True)
class CollectionResult:
    success: bool
    daily_rate: int
    outstanding_before_collection: int
    prior_arrears: int
    arrears_payment: int
    collected: int
    remaining_outstanding: int
    cash_delta: int
    accounts_receivable_delta: int
    partner1_memo_delta: int
    partner2_memo_delta: int


def daily_rate_for_contract(contract_type: str) -> int:
    if contract_type == "PRIMARY":
        return PRIMARY_DAILY_RENT
    if contract_type == "SECONDARY":
        return SECONDARY_DAILY_RENT
    raise ValueError(f"Unsupported contract_type: {contract_type}")


def collection_success(
    probability: float,
    *,
    master_seed: int,
    scenario_id: str,
    trial_id: int,
    bike_id: str,
    current_date: date,
    event_type: str,
) -> bool:
    """One Bernoulli collection decision using the binding SHA-256 RNG."""
    if not 0.0 <= probability <= 1.0:
        raise ValueError("collection probability must be in [0, 1]")
    if probability == 1.0:
        return True
    if probability == 0.0:
        return False
    seed = derive_seed(
        master_seed,
        scenario_id,
        trial_id,
        bike_id,
        current_date,
        event_type,
    )
    return rng_draw(seed) < probability


def apply_ordinary_collection(
    contract: Contract,
    *,
    probability: float,
    master_seed: int,
    scenario_id: str,
    trial_id: int,
    bike_id: str,
    current_date: date,
    event_type: str,
) -> CollectionResult:
    """Apply Chapter 6.2 to one already-accrued workday balance."""
    if event_type not in {"PRIMARY_COLLECTION", "SECONDARY_COLLECTION"}:
        raise ValueError("ordinary collection event_type must be PRIMARY_COLLECTION or SECONDARY_COLLECTION")

    daily_rate = daily_rate_for_contract(contract.contract_type)
    outstanding = contract.total_due - contract.total_paid
    if not is_business_day(current_date):
        return CollectionResult(
            success=False,
            daily_rate=daily_rate,
            outstanding_before_collection=outstanding,
            prior_arrears=max(0, outstanding - daily_rate),
            arrears_payment=0,
            collected=0,
            remaining_outstanding=outstanding,
            cash_delta=0,
            accounts_receivable_delta=0,
            partner1_memo_delta=0,
            partner2_memo_delta=0,
        )
    if outstanding < 0:
        raise ValueError("outstanding cannot be negative")

    success = collection_success(
        probability,
        master_seed=master_seed,
        scenario_id=scenario_id,
        trial_id=trial_id,
        bike_id=bike_id,
        current_date=current_date,
        event_type=event_type,
    )
    if not success or outstanding == 0:
        return CollectionResult(
            success=success,
            daily_rate=daily_rate,
            outstanding_before_collection=outstanding,
            prior_arrears=max(0, outstanding - daily_rate),
            arrears_payment=0,
            collected=0,
            remaining_outstanding=outstanding,
            cash_delta=0,
            accounts_receivable_delta=0,
            partner1_memo_delta=0,
            partner2_memo_delta=0,
        )

    prior_arrears = max(0, outstanding - daily_rate)
    arrears_payment = min(daily_rate, prior_arrears)
    collected = min(daily_rate + arrears_payment, outstanding)
    contract.total_paid += collected
    remaining = contract.total_due - contract.total_paid
    if remaining < 0:
        raise AssertionError("collection caused total_paid > total_due")

    return CollectionResult(
        success=True,
        daily_rate=daily_rate,
        outstanding_before_collection=outstanding,
        prior_arrears=prior_arrears,
        arrears_payment=arrears_payment,
        collected=collected,
        remaining_outstanding=remaining,
        cash_delta=collected,
        accounts_receivable_delta=-collected,
        partner1_memo_delta=(collected * 70) // 100,
        partner2_memo_delta=(collected * 30) // 100,
    )
